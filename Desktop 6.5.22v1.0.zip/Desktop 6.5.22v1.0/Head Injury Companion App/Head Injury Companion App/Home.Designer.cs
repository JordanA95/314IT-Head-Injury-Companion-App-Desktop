﻿namespace Head_Injury_Companion_App
{
    partial class home
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(home));
            this.Title = new System.Windows.Forms.Label();
            this.tipsandadvice_btn = new System.Windows.Forms.Button();
            this.dailylivingtasks_btn = new System.Windows.Forms.Button();
            this.myreminders_btn = new System.Windows.Forms.Button();
            this.mynotes_btn = new System.Windows.Forms.Button();
            this.helpandsupport_btn = new System.Windows.Forms.Button();
            this.accessability_btn = new System.Windows.Forms.Button();
            this.speechbubble = new System.Windows.Forms.PictureBox();
            this.notepad = new System.Windows.Forms.PictureBox();
            this.postitnote = new System.Windows.Forms.PictureBox();
            this.apphelp = new System.Windows.Forms.PictureBox();
            this.eye = new System.Windows.Forms.PictureBox();
            this.taskhelp = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.speechbubble)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.notepad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.postitnote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apphelp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.eye)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.taskhelp)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Arial Rounded MT Bold", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(197, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(708, 46);
            this.Title.TabIndex = 0;
            this.Title.Text = "Head Injury Companion Application";
            // 
            // tipsandadvice_btn
            // 
            this.tipsandadvice_btn.BackColor = System.Drawing.Color.Red;
            this.tipsandadvice_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.tipsandadvice_btn.ForeColor = System.Drawing.Color.White;
            this.tipsandadvice_btn.Location = new System.Drawing.Point(59, 133);
            this.tipsandadvice_btn.Name = "tipsandadvice_btn";
            this.tipsandadvice_btn.Size = new System.Drawing.Size(221, 115);
            this.tipsandadvice_btn.TabIndex = 1;
            this.tipsandadvice_btn.Text = "Tips and Advice Section";
            this.tipsandadvice_btn.UseVisualStyleBackColor = false;
            this.tipsandadvice_btn.Click += new System.EventHandler(this.tipsandadvice_btn_Click);
            // 
            // dailylivingtasks_btn
            // 
            this.dailylivingtasks_btn.BackColor = System.Drawing.Color.Red;
            this.dailylivingtasks_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dailylivingtasks_btn.ForeColor = System.Drawing.Color.White;
            this.dailylivingtasks_btn.Location = new System.Drawing.Point(657, 133);
            this.dailylivingtasks_btn.Name = "dailylivingtasks_btn";
            this.dailylivingtasks_btn.Size = new System.Drawing.Size(221, 115);
            this.dailylivingtasks_btn.TabIndex = 2;
            this.dailylivingtasks_btn.Text = "Need Help with Daily Living Tasks?";
            this.dailylivingtasks_btn.UseVisualStyleBackColor = false;
            // 
            // myreminders_btn
            // 
            this.myreminders_btn.BackColor = System.Drawing.Color.Red;
            this.myreminders_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.myreminders_btn.ForeColor = System.Drawing.Color.White;
            this.myreminders_btn.Location = new System.Drawing.Point(59, 302);
            this.myreminders_btn.Name = "myreminders_btn";
            this.myreminders_btn.Size = new System.Drawing.Size(221, 115);
            this.myreminders_btn.TabIndex = 3;
            this.myreminders_btn.Text = "My Reminders";
            this.myreminders_btn.UseVisualStyleBackColor = false;
            // 
            // mynotes_btn
            // 
            this.mynotes_btn.BackColor = System.Drawing.Color.Red;
            this.mynotes_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.mynotes_btn.ForeColor = System.Drawing.Color.White;
            this.mynotes_btn.Location = new System.Drawing.Point(657, 302);
            this.mynotes_btn.Name = "mynotes_btn";
            this.mynotes_btn.Size = new System.Drawing.Size(221, 115);
            this.mynotes_btn.TabIndex = 4;
            this.mynotes_btn.Text = "My Notes";
            this.mynotes_btn.UseVisualStyleBackColor = false;
            // 
            // helpandsupport_btn
            // 
            this.helpandsupport_btn.BackColor = System.Drawing.Color.Red;
            this.helpandsupport_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.helpandsupport_btn.ForeColor = System.Drawing.Color.White;
            this.helpandsupport_btn.Location = new System.Drawing.Point(59, 600);
            this.helpandsupport_btn.Name = "helpandsupport_btn";
            this.helpandsupport_btn.Size = new System.Drawing.Size(221, 73);
            this.helpandsupport_btn.TabIndex = 5;
            this.helpandsupport_btn.Text = "Application Help and Support";
            this.helpandsupport_btn.UseVisualStyleBackColor = false;
            // 
            // accessability_btn
            // 
            this.accessability_btn.BackColor = System.Drawing.Color.Red;
            this.accessability_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.accessability_btn.ForeColor = System.Drawing.Color.White;
            this.accessability_btn.Location = new System.Drawing.Point(657, 600);
            this.accessability_btn.Name = "accessability_btn";
            this.accessability_btn.Size = new System.Drawing.Size(221, 73);
            this.accessability_btn.TabIndex = 6;
            this.accessability_btn.Text = "Accessability Settings";
            this.accessability_btn.UseVisualStyleBackColor = false;
            // 
            // speechbubble
            // 
            this.speechbubble.Image = ((System.Drawing.Image)(resources.GetObject("speechbubble.Image")));
            this.speechbubble.Location = new System.Drawing.Point(286, 133);
            this.speechbubble.Name = "speechbubble";
            this.speechbubble.Size = new System.Drawing.Size(126, 114);
            this.speechbubble.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.speechbubble.TabIndex = 7;
            this.speechbubble.TabStop = false;
            // 
            // notepad
            // 
            this.notepad.Image = ((System.Drawing.Image)(resources.GetObject("notepad.Image")));
            this.notepad.Location = new System.Drawing.Point(884, 303);
            this.notepad.Name = "notepad";
            this.notepad.Size = new System.Drawing.Size(126, 114);
            this.notepad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.notepad.TabIndex = 9;
            this.notepad.TabStop = false;
            // 
            // postitnote
            // 
            this.postitnote.Image = ((System.Drawing.Image)(resources.GetObject("postitnote.Image")));
            this.postitnote.Location = new System.Drawing.Point(286, 302);
            this.postitnote.Name = "postitnote";
            this.postitnote.Size = new System.Drawing.Size(126, 114);
            this.postitnote.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.postitnote.TabIndex = 10;
            this.postitnote.TabStop = false;
            // 
            // apphelp
            // 
            this.apphelp.Image = ((System.Drawing.Image)(resources.GetObject("apphelp.Image")));
            this.apphelp.Location = new System.Drawing.Point(286, 574);
            this.apphelp.Name = "apphelp";
            this.apphelp.Size = new System.Drawing.Size(126, 114);
            this.apphelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.apphelp.TabIndex = 11;
            this.apphelp.TabStop = false;
            // 
            // eye
            // 
            this.eye.Image = ((System.Drawing.Image)(resources.GetObject("eye.Image")));
            this.eye.Location = new System.Drawing.Point(884, 574);
            this.eye.Name = "eye";
            this.eye.Size = new System.Drawing.Size(126, 114);
            this.eye.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.eye.TabIndex = 13;
            this.eye.TabStop = false;
            // 
            // taskhelp
            // 
            this.taskhelp.Image = ((System.Drawing.Image)(resources.GetObject("taskhelp.Image")));
            this.taskhelp.Location = new System.Drawing.Point(884, 133);
            this.taskhelp.Name = "taskhelp";
            this.taskhelp.Size = new System.Drawing.Size(126, 114);
            this.taskhelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.taskhelp.TabIndex = 14;
            this.taskhelp.TabStop = false;
            // 
            // home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1127, 700);
            this.Controls.Add(this.taskhelp);
            this.Controls.Add(this.eye);
            this.Controls.Add(this.apphelp);
            this.Controls.Add(this.postitnote);
            this.Controls.Add(this.notepad);
            this.Controls.Add(this.speechbubble);
            this.Controls.Add(this.accessability_btn);
            this.Controls.Add(this.helpandsupport_btn);
            this.Controls.Add(this.mynotes_btn);
            this.Controls.Add(this.myreminders_btn);
            this.Controls.Add(this.dailylivingtasks_btn);
            this.Controls.Add(this.tipsandadvice_btn);
            this.Controls.Add(this.Title);
            this.Name = "home";
            this.Text = "Home";
            ((System.ComponentModel.ISupportInitialize)(this.speechbubble)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.notepad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.postitnote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apphelp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.eye)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.taskhelp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Title;
        private Button tipsandadvice_btn;
        private Button dailylivingtasks_btn;
        private Button myreminders_btn;
        private Button mynotes_btn;
        private Button helpandsupport_btn;
        private Button accessability_btn;
        private PictureBox speechbubble;
        private PictureBox notepad;
        private PictureBox postitnote;
        private PictureBox apphelp;
        private PictureBox eye;
        private PictureBox taskhelp;
    }
}