﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace Head_Injury_Companion_App
{
    public partial class MyReminders : Form
    {
        private System.Timers.Timer timer;
        public MyReminders()
        {
            InitializeComponent();
        }
        private void MyReminders_Load(object sender, EventArgs e)
        {
            timer = new System.Timers.Timer();
            timer.Interval = 1000;
            timer.Elapsed += Timer_Elapsed;
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            timer.Start();
            MessageBox.Show("Your timer is started", "Starting...");
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            DateTime currentTime = DateTime.Now;
            DateTime userTime = dateTimePicker1.Value;
            if (currentTime.Hour == userTime.Hour && currentTime.Minute == userTime.Minute && currentTime.Second == userTime.Second)
            {
                timer.Stop();
                try
                {
                    MessageBox.Show("Timer is finished!!");
                }
                catch
                {
                    MessageBox.Show("Timer is finished!!");
                }
            }
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            timer.Stop();
            MessageBox.Show("Your timer is stopped", "Stopping...");
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show(); //Opens the "Home" form
        }
    }
}
