﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Head_Injury_Companion_App
{
    public partial class MyNotes : Form
    {
        public MyNotes()
        {
            InitializeComponent();
        }

        static public Font ChangeFontSize(Font font, float fontSize)
        {
            if (font != null)
            {
                float currentSize = font.Size;
                if (currentSize != fontSize)
                {
                    font = new Font(font.Name, fontSize,
                        font.Style, font.Unit,
                        font.GdiCharSet, font.GdiVerticalFont);
                }
            }
            return font;
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show(); //Opens the "Home" form
        }

        private void new_btn_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("If a note is open, any unsaved changes to your existing note will be lost. Are you sure you want to create a new note?", "New Note", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                notearea.Text = "";
                notearea.Visible = true;
            }
            else if (dialogResult == DialogResult.No)
            {
            }
        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (Stream s = File.Open(saveFileDialog1.FileName, FileMode.CreateNew))
                using (StreamWriter sw = new StreamWriter(s))
                {
                    sw.Write(notearea.Text);
                }
            }
        }

        private void open_btn_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialogue1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string s = File.ReadAllText(openFileDialog1.FileName);
                notearea.Text = s;
            }
        }

        private void font_size_up_Click(object sender, EventArgs e)
        {
            Title.Font = ChangeFontSize(Title.Font, Title.Font.Size + 1);
            Back_btn.Font = ChangeFontSize(Back_btn.Font, Back_btn.Font.Size + 1);
            new_btn.Font = ChangeFontSize(new_btn.Font, new_btn.Font.Size + 1);
            open_btn.Font = ChangeFontSize(open_btn.Font, open_btn.Font.Size + 1);
            save_btn.Font = ChangeFontSize(save_btn.Font, save_btn.Font.Size + 1);
            notearea.Font = ChangeFontSize(notearea.Font, notearea.Font.Size + 1);
        }

        private void font_size_down_Click(object sender, EventArgs e)
        {
            Title.Font = ChangeFontSize(Title.Font, Title.Font.Size - 1);
            Back_btn.Font = ChangeFontSize(Back_btn.Font, Back_btn.Font.Size - 1);
            new_btn.Font = ChangeFontSize(new_btn.Font, new_btn.Font.Size - 1);
            open_btn.Font = ChangeFontSize(open_btn.Font, open_btn.Font.Size - 1);
            save_btn.Font = ChangeFontSize(save_btn.Font, save_btn.Font.Size - 1);
            notearea.Font = ChangeFontSize(notearea.Font, notearea.Font.Size - 1);
        }

        private void white_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
        }

        private void yellow_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Yellow;
        }

        private void blue_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
        }

        private void black_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Black;
        }

        private void white_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.White;
            background_colour_lbl.ForeColor = Color.White;
            text_colour_lbl.ForeColor = Color.White;
            font_size_lbl.ForeColor = Color.White;
            note_background_colour_lbl.ForeColor= Color.White;
            note_text_colour_lbl.ForeColor = Color.White;
        }

        private void yellow_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.Yellow;
            background_colour_lbl.ForeColor = Color.Yellow;
            text_colour_lbl.ForeColor = Color.Yellow;
            font_size_lbl.ForeColor = Color.Yellow;
            note_background_colour_lbl.ForeColor = Color.Yellow;
            note_text_colour_lbl.ForeColor = Color.Yellow;
        }

        private void red_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.Red;
            background_colour_lbl.ForeColor = Color.Red;
            text_colour_lbl.ForeColor = Color.Red;
            font_size_lbl.ForeColor = Color.Red;
            note_background_colour_lbl.ForeColor = Color.Red;
            note_text_colour_lbl.ForeColor = Color.Red;
        }

        private void black_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.Black;
            background_colour_lbl.ForeColor = Color.Black;
            text_colour_lbl.ForeColor = Color.Black;
            font_size_lbl.ForeColor = Color.Black;
            note_background_colour_lbl.ForeColor = Color.Black;
            note_text_colour_lbl.ForeColor = Color.Black;
        }

        private void white_note_background_btn_Click(object sender, EventArgs e)
        {
            notearea.BackColor = Color.White;
        }

        private void yellow_note_backgrond_btn_Click(object sender, EventArgs e)
        {
            notearea.BackColor = Color.Yellow;
        }

        private void blue_note_background_btn_Click(object sender, EventArgs e)
        {
            notearea.BackColor = Color.Blue;
        }

        private void black_note_background_btn_Click(object sender, EventArgs e)
        {
            notearea.BackColor = Color.Black;
        }

        private void white_note_text_btn_Click(object sender, EventArgs e)
        {
            notearea.ForeColor = Color.White;
        }

        private void yellow_note_text_btn_Click(object sender, EventArgs e)
        {
            notearea.ForeColor = Color.Yellow;
        }

        private void red_note_text_btn_Click(object sender, EventArgs e)
        {
            notearea.ForeColor = Color.Red;
        }

        private void black_note_text_btn_Click(object sender, EventArgs e)
        {
            notearea.ForeColor = Color.Black;
        }
    }
}
