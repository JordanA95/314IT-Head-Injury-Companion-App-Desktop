﻿namespace Head_Injury_Companion_App
{
    partial class DailyLivingTaskHelp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DailyLivingTaskHelp));
            this.taskhelp = new System.Windows.Forms.PictureBox();
            this.Title = new System.Windows.Forms.Label();
            this.Back_btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.making_cup_of_tea_btn = new System.Windows.Forms.Button();
            this.making_sandwich_btn = new System.Windows.Forms.Button();
            this.washing_up_btn = new System.Windows.Forms.Button();
            this.brushing_teeth_btn = new System.Windows.Forms.Button();
            this.font_size_down = new System.Windows.Forms.Button();
            this.font_size_up = new System.Windows.Forms.Button();
            this.font_size_lbl = new System.Windows.Forms.Label();
            this.black_text_btn = new System.Windows.Forms.Button();
            this.red_text_btn = new System.Windows.Forms.Button();
            this.yellow_text_btn = new System.Windows.Forms.Button();
            this.white_text_btn = new System.Windows.Forms.Button();
            this.text_colour_lbl = new System.Windows.Forms.Label();
            this.black_background_btn = new System.Windows.Forms.Button();
            this.blue_background_btn = new System.Windows.Forms.Button();
            this.yellow_background_btn = new System.Windows.Forms.Button();
            this.white_background_btn = new System.Windows.Forms.Button();
            this.background_colour_lbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.taskhelp)).BeginInit();
            this.SuspendLayout();
            // 
            // taskhelp
            // 
            this.taskhelp.Image = ((System.Drawing.Image)(resources.GetObject("taskhelp.Image")));
            this.taskhelp.Location = new System.Drawing.Point(988, 12);
            this.taskhelp.Name = "taskhelp";
            this.taskhelp.Size = new System.Drawing.Size(126, 114);
            this.taskhelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.taskhelp.TabIndex = 15;
            this.taskhelp.TabStop = false;
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(337, 12);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(371, 38);
            this.Title.TabIndex = 16;
            this.Title.Text = "Daily Living Task Help";
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.Color.Red;
            this.Back_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Back_btn.ForeColor = System.Drawing.Color.White;
            this.Back_btn.Location = new System.Drawing.Point(12, 12);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(120, 64);
            this.Back_btn.TabIndex = 17;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = false;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(56, 214);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(688, 20);
            this.label1.TabIndex = 18;
            this.label1.Text = "Put a PictureBox here which will populate with whichever instructions are selecte" +
    "d.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(56, 234);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(742, 15);
            this.label2.TabIndex = 19;
            this.label2.Text = "Make instructions for each task (with images) on PPT and save each as a PNG which" +
    " can go in the PictureBox here.";
            // 
            // making_cup_of_tea_btn
            // 
            this.making_cup_of_tea_btn.BackColor = System.Drawing.Color.Red;
            this.making_cup_of_tea_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.making_cup_of_tea_btn.ForeColor = System.Drawing.Color.White;
            this.making_cup_of_tea_btn.Location = new System.Drawing.Point(840, 153);
            this.making_cup_of_tea_btn.Name = "making_cup_of_tea_btn";
            this.making_cup_of_tea_btn.Size = new System.Drawing.Size(227, 64);
            this.making_cup_of_tea_btn.TabIndex = 20;
            this.making_cup_of_tea_btn.Text = "Making a Cup of Tea";
            this.making_cup_of_tea_btn.UseVisualStyleBackColor = false;
            // 
            // making_sandwich_btn
            // 
            this.making_sandwich_btn.BackColor = System.Drawing.Color.Red;
            this.making_sandwich_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.making_sandwich_btn.ForeColor = System.Drawing.Color.White;
            this.making_sandwich_btn.Location = new System.Drawing.Point(840, 252);
            this.making_sandwich_btn.Name = "making_sandwich_btn";
            this.making_sandwich_btn.Size = new System.Drawing.Size(227, 64);
            this.making_sandwich_btn.TabIndex = 21;
            this.making_sandwich_btn.Text = "Making a Sandwich";
            this.making_sandwich_btn.UseVisualStyleBackColor = false;
            // 
            // washing_up_btn
            // 
            this.washing_up_btn.BackColor = System.Drawing.Color.Red;
            this.washing_up_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.washing_up_btn.ForeColor = System.Drawing.Color.White;
            this.washing_up_btn.Location = new System.Drawing.Point(840, 353);
            this.washing_up_btn.Name = "washing_up_btn";
            this.washing_up_btn.Size = new System.Drawing.Size(227, 64);
            this.washing_up_btn.TabIndex = 22;
            this.washing_up_btn.Text = "Washing Up";
            this.washing_up_btn.UseVisualStyleBackColor = false;
            // 
            // brushing_teeth_btn
            // 
            this.brushing_teeth_btn.BackColor = System.Drawing.Color.Red;
            this.brushing_teeth_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.brushing_teeth_btn.ForeColor = System.Drawing.Color.White;
            this.brushing_teeth_btn.Location = new System.Drawing.Point(840, 453);
            this.brushing_teeth_btn.Name = "brushing_teeth_btn";
            this.brushing_teeth_btn.Size = new System.Drawing.Size(227, 64);
            this.brushing_teeth_btn.TabIndex = 23;
            this.brushing_teeth_btn.Text = "Brushing My Teeth";
            this.brushing_teeth_btn.UseVisualStyleBackColor = false;
            // 
            // font_size_down
            // 
            this.font_size_down.BackColor = System.Drawing.Color.Red;
            this.font_size_down.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_down.ForeColor = System.Drawing.Color.White;
            this.font_size_down.Location = new System.Drawing.Point(1076, 644);
            this.font_size_down.Name = "font_size_down";
            this.font_size_down.Size = new System.Drawing.Size(38, 47);
            this.font_size_down.TabIndex = 26;
            this.font_size_down.Text = "-";
            this.font_size_down.UseVisualStyleBackColor = false;
            this.font_size_down.Click += new System.EventHandler(this.font_size_down_Click);
            // 
            // font_size_up
            // 
            this.font_size_up.BackColor = System.Drawing.Color.Red;
            this.font_size_up.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_up.ForeColor = System.Drawing.Color.White;
            this.font_size_up.Location = new System.Drawing.Point(1029, 644);
            this.font_size_up.Name = "font_size_up";
            this.font_size_up.Size = new System.Drawing.Size(38, 47);
            this.font_size_up.TabIndex = 25;
            this.font_size_up.Text = "+";
            this.font_size_up.UseVisualStyleBackColor = false;
            this.font_size_up.Click += new System.EventHandler(this.font_size_up_Click);
            // 
            // font_size_lbl
            // 
            this.font_size_lbl.AutoSize = true;
            this.font_size_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_lbl.ForeColor = System.Drawing.Color.White;
            this.font_size_lbl.Location = new System.Drawing.Point(907, 653);
            this.font_size_lbl.Name = "font_size_lbl";
            this.font_size_lbl.Size = new System.Drawing.Size(116, 33);
            this.font_size_lbl.TabIndex = 24;
            this.font_size_lbl.Text = "Font Size";
            // 
            // black_text_btn
            // 
            this.black_text_btn.BackColor = System.Drawing.Color.Black;
            this.black_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.black_text_btn.ForeColor = System.Drawing.Color.White;
            this.black_text_btn.Location = new System.Drawing.Point(734, 653);
            this.black_text_btn.Name = "black_text_btn";
            this.black_text_btn.Size = new System.Drawing.Size(38, 47);
            this.black_text_btn.TabIndex = 38;
            this.black_text_btn.UseVisualStyleBackColor = false;
            this.black_text_btn.Click += new System.EventHandler(this.black_text_btn_Click);
            // 
            // red_text_btn
            // 
            this.red_text_btn.BackColor = System.Drawing.Color.Red;
            this.red_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.red_text_btn.ForeColor = System.Drawing.Color.White;
            this.red_text_btn.Location = new System.Drawing.Point(690, 652);
            this.red_text_btn.Name = "red_text_btn";
            this.red_text_btn.Size = new System.Drawing.Size(38, 47);
            this.red_text_btn.TabIndex = 37;
            this.red_text_btn.UseVisualStyleBackColor = false;
            this.red_text_btn.Click += new System.EventHandler(this.red_text_btn_Click);
            // 
            // yellow_text_btn
            // 
            this.yellow_text_btn.BackColor = System.Drawing.Color.Yellow;
            this.yellow_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yellow_text_btn.ForeColor = System.Drawing.Color.White;
            this.yellow_text_btn.Location = new System.Drawing.Point(646, 652);
            this.yellow_text_btn.Name = "yellow_text_btn";
            this.yellow_text_btn.Size = new System.Drawing.Size(38, 47);
            this.yellow_text_btn.TabIndex = 36;
            this.yellow_text_btn.UseVisualStyleBackColor = false;
            this.yellow_text_btn.Click += new System.EventHandler(this.yellow_text_btn_Click);
            // 
            // white_text_btn
            // 
            this.white_text_btn.BackColor = System.Drawing.Color.White;
            this.white_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.white_text_btn.ForeColor = System.Drawing.Color.White;
            this.white_text_btn.Location = new System.Drawing.Point(602, 653);
            this.white_text_btn.Name = "white_text_btn";
            this.white_text_btn.Size = new System.Drawing.Size(38, 47);
            this.white_text_btn.TabIndex = 35;
            this.white_text_btn.UseVisualStyleBackColor = false;
            this.white_text_btn.Click += new System.EventHandler(this.white_text_btn_Click);
            // 
            // text_colour_lbl
            // 
            this.text_colour_lbl.AutoSize = true;
            this.text_colour_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.text_colour_lbl.ForeColor = System.Drawing.Color.White;
            this.text_colour_lbl.Location = new System.Drawing.Point(453, 662);
            this.text_colour_lbl.Name = "text_colour_lbl";
            this.text_colour_lbl.Size = new System.Drawing.Size(143, 33);
            this.text_colour_lbl.TabIndex = 34;
            this.text_colour_lbl.Text = "Text Colour";
            // 
            // black_background_btn
            // 
            this.black_background_btn.BackColor = System.Drawing.Color.Black;
            this.black_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.black_background_btn.ForeColor = System.Drawing.Color.White;
            this.black_background_btn.Location = new System.Drawing.Point(380, 653);
            this.black_background_btn.Name = "black_background_btn";
            this.black_background_btn.Size = new System.Drawing.Size(38, 47);
            this.black_background_btn.TabIndex = 33;
            this.black_background_btn.UseVisualStyleBackColor = false;
            this.black_background_btn.Click += new System.EventHandler(this.black_background_btn_Click);
            // 
            // blue_background_btn
            // 
            this.blue_background_btn.BackColor = System.Drawing.Color.Blue;
            this.blue_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.blue_background_btn.ForeColor = System.Drawing.Color.White;
            this.blue_background_btn.Location = new System.Drawing.Point(336, 652);
            this.blue_background_btn.Name = "blue_background_btn";
            this.blue_background_btn.Size = new System.Drawing.Size(38, 47);
            this.blue_background_btn.TabIndex = 32;
            this.blue_background_btn.UseVisualStyleBackColor = false;
            this.blue_background_btn.Click += new System.EventHandler(this.blue_background_btn_Click);
            // 
            // yellow_background_btn
            // 
            this.yellow_background_btn.BackColor = System.Drawing.Color.Yellow;
            this.yellow_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yellow_background_btn.ForeColor = System.Drawing.Color.White;
            this.yellow_background_btn.Location = new System.Drawing.Point(292, 652);
            this.yellow_background_btn.Name = "yellow_background_btn";
            this.yellow_background_btn.Size = new System.Drawing.Size(38, 47);
            this.yellow_background_btn.TabIndex = 31;
            this.yellow_background_btn.UseVisualStyleBackColor = false;
            this.yellow_background_btn.Click += new System.EventHandler(this.yellow_background_btn_Click);
            // 
            // white_background_btn
            // 
            this.white_background_btn.BackColor = System.Drawing.Color.White;
            this.white_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.white_background_btn.ForeColor = System.Drawing.Color.White;
            this.white_background_btn.Location = new System.Drawing.Point(248, 653);
            this.white_background_btn.Name = "white_background_btn";
            this.white_background_btn.Size = new System.Drawing.Size(38, 47);
            this.white_background_btn.TabIndex = 30;
            this.white_background_btn.UseVisualStyleBackColor = false;
            this.white_background_btn.Click += new System.EventHandler(this.white_background_btn_Click);
            // 
            // background_colour_lbl
            // 
            this.background_colour_lbl.AutoSize = true;
            this.background_colour_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.background_colour_lbl.ForeColor = System.Drawing.Color.White;
            this.background_colour_lbl.Location = new System.Drawing.Point(12, 661);
            this.background_colour_lbl.Name = "background_colour_lbl";
            this.background_colour_lbl.Size = new System.Drawing.Size(230, 33);
            this.background_colour_lbl.TabIndex = 29;
            this.background_colour_lbl.Text = "Background Colour";
            // 
            // DailyLivingTaskHelp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1126, 703);
            this.Controls.Add(this.black_text_btn);
            this.Controls.Add(this.red_text_btn);
            this.Controls.Add(this.yellow_text_btn);
            this.Controls.Add(this.white_text_btn);
            this.Controls.Add(this.text_colour_lbl);
            this.Controls.Add(this.black_background_btn);
            this.Controls.Add(this.blue_background_btn);
            this.Controls.Add(this.yellow_background_btn);
            this.Controls.Add(this.white_background_btn);
            this.Controls.Add(this.background_colour_lbl);
            this.Controls.Add(this.font_size_down);
            this.Controls.Add(this.font_size_up);
            this.Controls.Add(this.font_size_lbl);
            this.Controls.Add(this.brushing_teeth_btn);
            this.Controls.Add(this.washing_up_btn);
            this.Controls.Add(this.making_sandwich_btn);
            this.Controls.Add(this.making_cup_of_tea_btn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.taskhelp);
            this.Name = "DailyLivingTaskHelp";
            this.Text = "DailyLivingTaskHelp";
            ((System.ComponentModel.ISupportInitialize)(this.taskhelp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private PictureBox taskhelp;
        private Label Title;
        private Button Back_btn;
        private Label label1;
        private Label label2;
        private Button making_cup_of_tea_btn;
        private Button making_sandwich_btn;
        private Button washing_up_btn;
        private Button brushing_teeth_btn;
        private Button font_size_down;
        private Button font_size_up;
        private Label font_size_lbl;
        private Button black_text_btn;
        private Button red_text_btn;
        private Button yellow_text_btn;
        private Button white_text_btn;
        private Label text_colour_lbl;
        private Button black_background_btn;
        private Button blue_background_btn;
        private Button yellow_background_btn;
        private Button white_background_btn;
        private Label background_colour_lbl;
    }
}