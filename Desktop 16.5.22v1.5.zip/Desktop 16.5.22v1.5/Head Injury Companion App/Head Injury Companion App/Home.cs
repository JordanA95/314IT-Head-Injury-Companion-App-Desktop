using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Head_Injury_Companion_App
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void tipsandadvice_btn_Click(object sender, EventArgs e)
        {
            TipsAndAdvice tipsandadvice = new TipsAndAdvice();
            tipsandadvice.Show(); //Opens the "TipsAndAdvice" form
        }

        private void helpandsupport_btn_Click(object sender, EventArgs e)
        {
            ApplicationHelpAndSupport ApplicationHelpAndSupport = new ApplicationHelpAndSupport();
            ApplicationHelpAndSupport.Show(); //Opens the "Application Help and Support" form
        }

        private void dailylivingtasks_btn_Click(object sender, EventArgs e)
        {
            DailyLivingTaskHelp DailyLivingTaskHelp = new DailyLivingTaskHelp();
            DailyLivingTaskHelp.Show(); //Opens the "Application Help and Support" form
        }

        private void myreminders_btn_Click(object sender, EventArgs e)
        {
            MyReminders MyReminders = new MyReminders();
            MyReminders.Show(); //Opens the "Application Help and Support" form
        }

        private void mynotes_btn_Click(object sender, EventArgs e)
        {
            MyNotes MyNotes = new MyNotes();
            MyNotes.Show(); //Opens the "My Notes" form
        }
    }
}