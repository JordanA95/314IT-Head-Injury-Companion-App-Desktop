﻿namespace Head_Injury_Companion_App
{
    partial class TipsAndAdvice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TipsAndAdvice));
            this.Title = new System.Windows.Forms.Label();
            this.speechbubble = new System.Windows.Forms.PictureBox();
            this.Back_btn = new System.Windows.Forms.Button();
            this.tips_and_advice_web = new Microsoft.Web.WebView2.WinForms.WebView2();
            ((System.ComponentModel.ISupportInitialize)(this.speechbubble)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tips_and_advice_web)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(418, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(275, 38);
            this.Title.TabIndex = 1;
            this.Title.Text = "Tips and Advice";
            // 
            // speechbubble
            // 
            this.speechbubble.Image = ((System.Drawing.Image)(resources.GetObject("speechbubble.Image")));
            this.speechbubble.Location = new System.Drawing.Point(988, 12);
            this.speechbubble.Name = "speechbubble";
            this.speechbubble.Size = new System.Drawing.Size(126, 114);
            this.speechbubble.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.speechbubble.TabIndex = 8;
            this.speechbubble.TabStop = false;
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.Color.Red;
            this.Back_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Back_btn.ForeColor = System.Drawing.Color.White;
            this.Back_btn.Location = new System.Drawing.Point(12, 12);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(120, 64);
            this.Back_btn.TabIndex = 9;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = false;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // tips_and_advice_web
            // 
            this.tips_and_advice_web.AllowExternalDrop = true;
            this.tips_and_advice_web.CreationProperties = null;
            this.tips_and_advice_web.DefaultBackgroundColor = System.Drawing.Color.White;
            this.tips_and_advice_web.Location = new System.Drawing.Point(12, 132);
            this.tips_and_advice_web.Name = "tips_and_advice_web";
            this.tips_and_advice_web.Size = new System.Drawing.Size(1102, 558);
            this.tips_and_advice_web.Source = new System.Uri("https://adamso10.wixsite.com/head-injury-tips", System.UriKind.Absolute);
            this.tips_and_advice_web.TabIndex = 10;
            this.tips_and_advice_web.ZoomFactor = 1D;
            // 
            // TipsAndAdvice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1126, 702);
            this.Controls.Add(this.tips_and_advice_web);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.speechbubble);
            this.Controls.Add(this.Title);
            this.Name = "TipsAndAdvice";
            this.Text = "TipsAndAdvice";
            ((System.ComponentModel.ISupportInitialize)(this.speechbubble)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tips_and_advice_web)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Title;
        private PictureBox speechbubble;
        private Button Back_btn;
        private Microsoft.Web.WebView2.WinForms.WebView2 tips_and_advice_web;
    }
}