﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Head_Injury_Companion_App
{
    public partial class ApplicationHelpAndSupport : Form
    {
        public ApplicationHelpAndSupport()
        {
            InitializeComponent();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show(); //Opens the "Home" form
        }

        private void submit_btn_Click(object sender, EventArgs e)
        {
            string send_new_query = "mailto:adamson10[at]uni.coventry.ac.uk?subject=New Head Injury Companion App query&amp;body=new_question_txb.Text";
            Process.Start(send_new_query); //executes the send_new_query process which creates an email populated with recipient email, subject, and the question entered into the new_question_txb textbox.
        }
    }
}
