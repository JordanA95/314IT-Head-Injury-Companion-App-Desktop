﻿namespace Head_Injury_Companion_App
{
    partial class ApplicationHelpAndSupport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ApplicationHelpAndSupport));
            this.Title = new System.Windows.Forms.Label();
            this.apphelp = new System.Windows.Forms.PictureBox();
            this.FAQ_txb = new System.Windows.Forms.TextBox();
            this.Back_btn = new System.Windows.Forms.Button();
            this.new_question_txb = new System.Windows.Forms.TextBox();
            this.submit_btn = new System.Windows.Forms.Button();
            this.cant_find_faq_lbl = new System.Windows.Forms.Label();
            this.new_question_info_lbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.apphelp)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(287, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(492, 38);
            this.Title.TabIndex = 2;
            this.Title.Text = "Application Help and Support";
            // 
            // apphelp
            // 
            this.apphelp.Image = ((System.Drawing.Image)(resources.GetObject("apphelp.Image")));
            this.apphelp.Location = new System.Drawing.Point(989, 12);
            this.apphelp.Name = "apphelp";
            this.apphelp.Size = new System.Drawing.Size(126, 114);
            this.apphelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.apphelp.TabIndex = 12;
            this.apphelp.TabStop = false;
            // 
            // FAQ_txb
            // 
            this.FAQ_txb.Location = new System.Drawing.Point(12, 193);
            this.FAQ_txb.Multiline = true;
            this.FAQ_txb.Name = "FAQ_txb";
            this.FAQ_txb.ReadOnly = true;
            this.FAQ_txb.Size = new System.Drawing.Size(1103, 580);
            this.FAQ_txb.TabIndex = 13;
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.Color.Red;
            this.Back_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Back_btn.ForeColor = System.Drawing.Color.White;
            this.Back_btn.Location = new System.Drawing.Point(12, 12);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(120, 64);
            this.Back_btn.TabIndex = 14;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = false;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // new_question_txb
            // 
            this.new_question_txb.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.new_question_txb.Location = new System.Drawing.Point(12, 141);
            this.new_question_txb.Multiline = true;
            this.new_question_txb.Name = "new_question_txb";
            this.new_question_txb.Size = new System.Drawing.Size(738, 46);
            this.new_question_txb.TabIndex = 15;
            // 
            // submit_btn
            // 
            this.submit_btn.BackColor = System.Drawing.Color.Red;
            this.submit_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.submit_btn.ForeColor = System.Drawing.Color.White;
            this.submit_btn.Location = new System.Drawing.Point(756, 141);
            this.submit_btn.Name = "submit_btn";
            this.submit_btn.Size = new System.Drawing.Size(227, 46);
            this.submit_btn.TabIndex = 16;
            this.submit_btn.Text = "Submit New Question";
            this.submit_btn.UseVisualStyleBackColor = false;
            this.submit_btn.Click += new System.EventHandler(this.submit_btn_Click);
            // 
            // cant_find_faq_lbl
            // 
            this.cant_find_faq_lbl.AutoSize = true;
            this.cant_find_faq_lbl.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cant_find_faq_lbl.ForeColor = System.Drawing.Color.White;
            this.cant_find_faq_lbl.Location = new System.Drawing.Point(12, 90);
            this.cant_find_faq_lbl.Name = "cant_find_faq_lbl";
            this.cant_find_faq_lbl.Size = new System.Drawing.Size(537, 24);
            this.cant_find_faq_lbl.TabIndex = 17;
            this.cant_find_faq_lbl.Text = "Can\'t find the question and answer you are looking for?";
            // 
            // new_question_info_lbl
            // 
            this.new_question_info_lbl.AutoSize = true;
            this.new_question_info_lbl.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.new_question_info_lbl.ForeColor = System.Drawing.Color.White;
            this.new_question_info_lbl.Location = new System.Drawing.Point(12, 114);
            this.new_question_info_lbl.Name = "new_question_info_lbl";
            this.new_question_info_lbl.Size = new System.Drawing.Size(646, 24);
            this.new_question_info_lbl.TabIndex = 18;
            this.new_question_info_lbl.Text = "Ask a new one here and our team will respond as soon as possible.";
            // 
            // ApplicationHelpAndSupport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1127, 703);
            this.Controls.Add(this.new_question_info_lbl);
            this.Controls.Add(this.cant_find_faq_lbl);
            this.Controls.Add(this.submit_btn);
            this.Controls.Add(this.new_question_txb);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.FAQ_txb);
            this.Controls.Add(this.apphelp);
            this.Controls.Add(this.Title);
            this.Name = "ApplicationHelpAndSupport";
            this.Text = "ApplicationHelpAndSupport";
            ((System.ComponentModel.ISupportInitialize)(this.apphelp)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Title;
        private PictureBox apphelp;
        private TextBox FAQ_txb;
        private Button Back_btn;
        private TextBox new_question_txb;
        private Button submit_btn;
        private Label cant_find_faq_lbl;
        private Label new_question_info_lbl;
    }
}