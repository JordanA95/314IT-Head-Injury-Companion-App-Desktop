﻿namespace Head_Injury_Companion_App
{
    partial class OnlineNotes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OnlineNotes));
            this.Title = new System.Windows.Forms.Label();
            this.notepad = new System.Windows.Forms.PictureBox();
            this.Back_btn = new System.Windows.Forms.Button();
            this.cancelbtn = new System.Windows.Forms.Button();
            this.saveselectednotebtn = new System.Windows.Forms.Button();
            this.addnewnotebtn = new System.Windows.Forms.Button();
            this.refreshnotebtn = new System.Windows.Forms.Button();
            this.deleteselectednotebtn = new System.Windows.Forms.Button();
            this.updateselectednotebtn = new System.Windows.Forms.Button();
            this.savenewnotebtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.onlinenotedgv = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.notepad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlinenotedgv)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(388, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(224, 38);
            this.Title.TabIndex = 2;
            this.Title.Text = "Online Notes";
            // 
            // notepad
            // 
            this.notepad.Image = ((System.Drawing.Image)(resources.GetObject("notepad.Image")));
            this.notepad.Location = new System.Drawing.Point(987, 12);
            this.notepad.Name = "notepad";
            this.notepad.Size = new System.Drawing.Size(126, 114);
            this.notepad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.notepad.TabIndex = 16;
            this.notepad.TabStop = false;
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.Color.Red;
            this.Back_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Back_btn.ForeColor = System.Drawing.Color.White;
            this.Back_btn.Location = new System.Drawing.Point(12, 12);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(120, 64);
            this.Back_btn.TabIndex = 17;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = false;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // cancelbtn
            // 
            this.cancelbtn.BackColor = System.Drawing.Color.Red;
            this.cancelbtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.cancelbtn.ForeColor = System.Drawing.Color.White;
            this.cancelbtn.Location = new System.Drawing.Point(464, 149);
            this.cancelbtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cancelbtn.Name = "cancelbtn";
            this.cancelbtn.Size = new System.Drawing.Size(157, 43);
            this.cancelbtn.TabIndex = 55;
            this.cancelbtn.Text = "Cancel";
            this.cancelbtn.UseVisualStyleBackColor = false;
            // 
            // saveselectednotebtn
            // 
            this.saveselectednotebtn.BackColor = System.Drawing.Color.Red;
            this.saveselectednotebtn.Enabled = false;
            this.saveselectednotebtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.saveselectednotebtn.ForeColor = System.Drawing.Color.White;
            this.saveselectednotebtn.Location = new System.Drawing.Point(627, 59);
            this.saveselectednotebtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.saveselectednotebtn.Name = "saveselectednotebtn";
            this.saveselectednotebtn.Size = new System.Drawing.Size(157, 39);
            this.saveselectednotebtn.TabIndex = 54;
            this.saveselectednotebtn.Text = "Save Selected";
            this.saveselectednotebtn.UseVisualStyleBackColor = false;
            // 
            // addnewnotebtn
            // 
            this.addnewnotebtn.BackColor = System.Drawing.Color.Red;
            this.addnewnotebtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.addnewnotebtn.ForeColor = System.Drawing.Color.White;
            this.addnewnotebtn.Location = new System.Drawing.Point(464, 59);
            this.addnewnotebtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.addnewnotebtn.Name = "addnewnotebtn";
            this.addnewnotebtn.Size = new System.Drawing.Size(157, 39);
            this.addnewnotebtn.TabIndex = 53;
            this.addnewnotebtn.Text = "Add New";
            this.addnewnotebtn.UseVisualStyleBackColor = false;
            // 
            // refreshnotebtn
            // 
            this.refreshnotebtn.BackColor = System.Drawing.Color.Red;
            this.refreshnotebtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.refreshnotebtn.ForeColor = System.Drawing.Color.White;
            this.refreshnotebtn.Location = new System.Drawing.Point(627, 102);
            this.refreshnotebtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.refreshnotebtn.Name = "refreshnotebtn";
            this.refreshnotebtn.Size = new System.Drawing.Size(157, 39);
            this.refreshnotebtn.TabIndex = 52;
            this.refreshnotebtn.Text = "Refresh";
            this.refreshnotebtn.UseVisualStyleBackColor = false;
            // 
            // deleteselectednotebtn
            // 
            this.deleteselectednotebtn.BackColor = System.Drawing.Color.Red;
            this.deleteselectednotebtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.deleteselectednotebtn.ForeColor = System.Drawing.Color.White;
            this.deleteselectednotebtn.Location = new System.Drawing.Point(464, 102);
            this.deleteselectednotebtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.deleteselectednotebtn.Name = "deleteselectednotebtn";
            this.deleteselectednotebtn.Size = new System.Drawing.Size(157, 39);
            this.deleteselectednotebtn.TabIndex = 51;
            this.deleteselectednotebtn.Text = "Delete Selected";
            this.deleteselectednotebtn.UseVisualStyleBackColor = false;
            // 
            // updateselectednotebtn
            // 
            this.updateselectednotebtn.BackColor = System.Drawing.Color.Red;
            this.updateselectednotebtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.updateselectednotebtn.ForeColor = System.Drawing.Color.White;
            this.updateselectednotebtn.Location = new System.Drawing.Point(301, 59);
            this.updateselectednotebtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.updateselectednotebtn.Name = "updateselectednotebtn";
            this.updateselectednotebtn.Size = new System.Drawing.Size(157, 39);
            this.updateselectednotebtn.TabIndex = 50;
            this.updateselectednotebtn.Text = "Update Selected";
            this.updateselectednotebtn.UseVisualStyleBackColor = false;
            // 
            // savenewnotebtn
            // 
            this.savenewnotebtn.BackColor = System.Drawing.Color.Red;
            this.savenewnotebtn.Enabled = false;
            this.savenewnotebtn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.savenewnotebtn.ForeColor = System.Drawing.Color.White;
            this.savenewnotebtn.Location = new System.Drawing.Point(301, 102);
            this.savenewnotebtn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.savenewnotebtn.Name = "savenewnotebtn";
            this.savenewnotebtn.Size = new System.Drawing.Size(157, 39);
            this.savenewnotebtn.TabIndex = 49;
            this.savenewnotebtn.Text = "Save New";
            this.savenewnotebtn.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 172);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 24);
            this.label1.TabIndex = 56;
            this.label1.Text = "Online Note:";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 199);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(1101, 284);
            this.textBox1.TabIndex = 57;
            // 
            // onlinenotedgv
            // 
            this.onlinenotedgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.onlinenotedgv.Location = new System.Drawing.Point(12, 489);
            this.onlinenotedgv.Name = "onlinenotedgv";
            this.onlinenotedgv.RowHeadersWidth = 51;
            this.onlinenotedgv.RowTemplate.Height = 29;
            this.onlinenotedgv.Size = new System.Drawing.Size(1101, 200);
            this.onlinenotedgv.TabIndex = 58;
            // 
            // OnlineNotes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1125, 701);
            this.Controls.Add(this.onlinenotedgv);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cancelbtn);
            this.Controls.Add(this.saveselectednotebtn);
            this.Controls.Add(this.addnewnotebtn);
            this.Controls.Add(this.refreshnotebtn);
            this.Controls.Add(this.deleteselectednotebtn);
            this.Controls.Add(this.updateselectednotebtn);
            this.Controls.Add(this.savenewnotebtn);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.notepad);
            this.Controls.Add(this.Title);
            this.Name = "OnlineNotes";
            this.Text = "OnlineNotes";
            ((System.ComponentModel.ISupportInitialize)(this.notepad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.onlinenotedgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Title;
        private PictureBox notepad;
        private Button Back_btn;
        private Button cancelbtn;
        private Button saveselectednotebtn;
        private Button addnewnotebtn;
        private Button refreshnotebtn;
        private Button deleteselectednotebtn;
        private Button updateselectednotebtn;
        private Button savenewnotebtn;
        private Label label1;
        private TextBox textBox1;
        private DataGridView onlinenotedgv;
    }
}