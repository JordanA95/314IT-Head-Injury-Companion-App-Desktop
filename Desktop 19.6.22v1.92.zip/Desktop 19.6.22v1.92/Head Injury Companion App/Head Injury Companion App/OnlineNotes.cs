﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Head_Injury_Companion_App
{
    public partial class OnlineNotes : Form
    {
        public OnlineNotes()
        {
            InitializeComponent();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            MyNotes MyNotes = new MyNotes();
            MyNotes.Show(); //Opens the "My Notes" form
        }
    }
}
