﻿using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySqlConnector;

namespace Head_Injury_Companion_App
{
    public class DbConn
    {
        //Database connection string for connecting to the headapp AWS Database instance.
        private string connstring = "server=headapp.cub20pif3hru.us-east-1.rds.amazonaws.com; Port=3306; Database=headapp; User ID=admin; Password=headinjuryapp";

    }

    //Write stored procedures here...
}
