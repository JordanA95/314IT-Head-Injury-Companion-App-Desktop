﻿namespace Head_Injury_Companion_App
{
    partial class MyReminders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MyReminders));
            this.Title = new System.Windows.Forms.Label();
            this.postitnote = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.startButton = new System.Windows.Forms.Button();
            this.stopButton = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.Back_btn = new System.Windows.Forms.Button();
            this.font_size_down = new System.Windows.Forms.Button();
            this.font_size_up = new System.Windows.Forms.Button();
            this.font_size_lbl = new System.Windows.Forms.Label();
            this.black_text_btn = new System.Windows.Forms.Button();
            this.red_text_btn = new System.Windows.Forms.Button();
            this.yellow_text_btn = new System.Windows.Forms.Button();
            this.white_text_btn = new System.Windows.Forms.Button();
            this.text_colour_lbl = new System.Windows.Forms.Label();
            this.black_background_btn = new System.Windows.Forms.Button();
            this.blue_background_btn = new System.Windows.Forms.Button();
            this.yellow_background_btn = new System.Windows.Forms.Button();
            this.white_background_btn = new System.Windows.Forms.Button();
            this.background_colour_lbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.postitnote)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(410, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(245, 38);
            this.Title.TabIndex = 2;
            this.Title.Text = "My Reminders";
            // 
            // postitnote
            // 
            this.postitnote.Image = ((System.Drawing.Image)(resources.GetObject("postitnote.Image")));
            this.postitnote.Location = new System.Drawing.Point(987, 12);
            this.postitnote.Name = "postitnote";
            this.postitnote.Size = new System.Drawing.Size(126, 114);
            this.postitnote.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.postitnote.TabIndex = 11;
            this.postitnote.TabStop = false;
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.Color.Red;
            this.startButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.startButton.ForeColor = System.Drawing.Color.White;
            this.startButton.Location = new System.Drawing.Point(37, 151);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(132, 54);
            this.startButton.TabIndex = 12;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // stopButton
            // 
            this.stopButton.BackColor = System.Drawing.Color.Red;
            this.stopButton.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.stopButton.ForeColor = System.Drawing.Color.White;
            this.stopButton.Location = new System.Drawing.Point(175, 151);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(132, 54);
            this.stopButton.TabIndex = 13;
            this.stopButton.Text = "Stop";
            this.stopButton.UseVisualStyleBackColor = false;
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker1.Location = new System.Drawing.Point(37, 118);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(270, 27);
            this.dateTimePicker1.TabIndex = 14;
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.Color.Red;
            this.Back_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Back_btn.ForeColor = System.Drawing.Color.White;
            this.Back_btn.Location = new System.Drawing.Point(12, 12);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(120, 64);
            this.Back_btn.TabIndex = 15;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = false;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // font_size_down
            // 
            this.font_size_down.BackColor = System.Drawing.Color.Red;
            this.font_size_down.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_down.ForeColor = System.Drawing.Color.White;
            this.font_size_down.Location = new System.Drawing.Point(1075, 644);
            this.font_size_down.Name = "font_size_down";
            this.font_size_down.Size = new System.Drawing.Size(38, 47);
            this.font_size_down.TabIndex = 26;
            this.font_size_down.Text = "-";
            this.font_size_down.UseVisualStyleBackColor = false;
            this.font_size_down.Click += new System.EventHandler(this.font_size_down_Click);
            // 
            // font_size_up
            // 
            this.font_size_up.BackColor = System.Drawing.Color.Red;
            this.font_size_up.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_up.ForeColor = System.Drawing.Color.White;
            this.font_size_up.Location = new System.Drawing.Point(1031, 644);
            this.font_size_up.Name = "font_size_up";
            this.font_size_up.Size = new System.Drawing.Size(38, 47);
            this.font_size_up.TabIndex = 25;
            this.font_size_up.Text = "+";
            this.font_size_up.UseVisualStyleBackColor = false;
            this.font_size_up.Click += new System.EventHandler(this.font_size_up_Click);
            // 
            // font_size_lbl
            // 
            this.font_size_lbl.AutoSize = true;
            this.font_size_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_lbl.ForeColor = System.Drawing.Color.White;
            this.font_size_lbl.Location = new System.Drawing.Point(909, 653);
            this.font_size_lbl.Name = "font_size_lbl";
            this.font_size_lbl.Size = new System.Drawing.Size(116, 33);
            this.font_size_lbl.TabIndex = 24;
            this.font_size_lbl.Text = "Font Size";
            // 
            // black_text_btn
            // 
            this.black_text_btn.BackColor = System.Drawing.Color.Black;
            this.black_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.black_text_btn.ForeColor = System.Drawing.Color.White;
            this.black_text_btn.Location = new System.Drawing.Point(734, 645);
            this.black_text_btn.Name = "black_text_btn";
            this.black_text_btn.Size = new System.Drawing.Size(38, 47);
            this.black_text_btn.TabIndex = 38;
            this.black_text_btn.UseVisualStyleBackColor = false;
            this.black_text_btn.Click += new System.EventHandler(this.black_text_btn_Click);
            // 
            // red_text_btn
            // 
            this.red_text_btn.BackColor = System.Drawing.Color.Red;
            this.red_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.red_text_btn.ForeColor = System.Drawing.Color.White;
            this.red_text_btn.Location = new System.Drawing.Point(690, 644);
            this.red_text_btn.Name = "red_text_btn";
            this.red_text_btn.Size = new System.Drawing.Size(38, 47);
            this.red_text_btn.TabIndex = 37;
            this.red_text_btn.UseVisualStyleBackColor = false;
            this.red_text_btn.Click += new System.EventHandler(this.red_text_btn_Click);
            // 
            // yellow_text_btn
            // 
            this.yellow_text_btn.BackColor = System.Drawing.Color.Yellow;
            this.yellow_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yellow_text_btn.ForeColor = System.Drawing.Color.White;
            this.yellow_text_btn.Location = new System.Drawing.Point(646, 644);
            this.yellow_text_btn.Name = "yellow_text_btn";
            this.yellow_text_btn.Size = new System.Drawing.Size(38, 47);
            this.yellow_text_btn.TabIndex = 36;
            this.yellow_text_btn.UseVisualStyleBackColor = false;
            this.yellow_text_btn.Click += new System.EventHandler(this.yellow_text_btn_Click);
            // 
            // white_text_btn
            // 
            this.white_text_btn.BackColor = System.Drawing.Color.White;
            this.white_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.white_text_btn.ForeColor = System.Drawing.Color.White;
            this.white_text_btn.Location = new System.Drawing.Point(602, 645);
            this.white_text_btn.Name = "white_text_btn";
            this.white_text_btn.Size = new System.Drawing.Size(38, 47);
            this.white_text_btn.TabIndex = 35;
            this.white_text_btn.UseVisualStyleBackColor = false;
            this.white_text_btn.Click += new System.EventHandler(this.white_text_btn_Click);
            // 
            // text_colour_lbl
            // 
            this.text_colour_lbl.AutoSize = true;
            this.text_colour_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.text_colour_lbl.ForeColor = System.Drawing.Color.White;
            this.text_colour_lbl.Location = new System.Drawing.Point(453, 654);
            this.text_colour_lbl.Name = "text_colour_lbl";
            this.text_colour_lbl.Size = new System.Drawing.Size(143, 33);
            this.text_colour_lbl.TabIndex = 34;
            this.text_colour_lbl.Text = "Text Colour";
            // 
            // black_background_btn
            // 
            this.black_background_btn.BackColor = System.Drawing.Color.Black;
            this.black_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.black_background_btn.ForeColor = System.Drawing.Color.White;
            this.black_background_btn.Location = new System.Drawing.Point(380, 645);
            this.black_background_btn.Name = "black_background_btn";
            this.black_background_btn.Size = new System.Drawing.Size(38, 47);
            this.black_background_btn.TabIndex = 33;
            this.black_background_btn.UseVisualStyleBackColor = false;
            this.black_background_btn.Click += new System.EventHandler(this.black_background_btn_Click);
            // 
            // blue_background_btn
            // 
            this.blue_background_btn.BackColor = System.Drawing.Color.Blue;
            this.blue_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.blue_background_btn.ForeColor = System.Drawing.Color.White;
            this.blue_background_btn.Location = new System.Drawing.Point(336, 644);
            this.blue_background_btn.Name = "blue_background_btn";
            this.blue_background_btn.Size = new System.Drawing.Size(38, 47);
            this.blue_background_btn.TabIndex = 32;
            this.blue_background_btn.UseVisualStyleBackColor = false;
            this.blue_background_btn.Click += new System.EventHandler(this.blue_background_btn_Click);
            // 
            // yellow_background_btn
            // 
            this.yellow_background_btn.BackColor = System.Drawing.Color.Yellow;
            this.yellow_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yellow_background_btn.ForeColor = System.Drawing.Color.White;
            this.yellow_background_btn.Location = new System.Drawing.Point(292, 644);
            this.yellow_background_btn.Name = "yellow_background_btn";
            this.yellow_background_btn.Size = new System.Drawing.Size(38, 47);
            this.yellow_background_btn.TabIndex = 31;
            this.yellow_background_btn.UseVisualStyleBackColor = false;
            this.yellow_background_btn.Click += new System.EventHandler(this.yellow_background_btn_Click);
            // 
            // white_background_btn
            // 
            this.white_background_btn.BackColor = System.Drawing.Color.White;
            this.white_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.white_background_btn.ForeColor = System.Drawing.Color.White;
            this.white_background_btn.Location = new System.Drawing.Point(248, 645);
            this.white_background_btn.Name = "white_background_btn";
            this.white_background_btn.Size = new System.Drawing.Size(38, 47);
            this.white_background_btn.TabIndex = 30;
            this.white_background_btn.UseVisualStyleBackColor = false;
            this.white_background_btn.Click += new System.EventHandler(this.white_background_btn_Click);
            // 
            // background_colour_lbl
            // 
            this.background_colour_lbl.AutoSize = true;
            this.background_colour_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.background_colour_lbl.ForeColor = System.Drawing.Color.White;
            this.background_colour_lbl.Location = new System.Drawing.Point(12, 653);
            this.background_colour_lbl.Name = "background_colour_lbl";
            this.background_colour_lbl.Size = new System.Drawing.Size(230, 33);
            this.background_colour_lbl.TabIndex = 29;
            this.background_colour_lbl.Text = "Background Colour";
            // 
            // MyReminders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1125, 703);
            this.Controls.Add(this.black_text_btn);
            this.Controls.Add(this.red_text_btn);
            this.Controls.Add(this.yellow_text_btn);
            this.Controls.Add(this.white_text_btn);
            this.Controls.Add(this.text_colour_lbl);
            this.Controls.Add(this.black_background_btn);
            this.Controls.Add(this.blue_background_btn);
            this.Controls.Add(this.yellow_background_btn);
            this.Controls.Add(this.white_background_btn);
            this.Controls.Add(this.background_colour_lbl);
            this.Controls.Add(this.font_size_down);
            this.Controls.Add(this.font_size_up);
            this.Controls.Add(this.font_size_lbl);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.stopButton);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.postitnote);
            this.Controls.Add(this.Title);
            this.Name = "MyReminders";
            this.Text = "MyReminders";
            ((System.ComponentModel.ISupportInitialize)(this.postitnote)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Title;
        private PictureBox postitnote;
        private System.Windows.Forms.Timer timer1;
        private Button startButton;
        private Button stopButton;
        private DateTimePicker dateTimePicker1;
        private Button Back_btn;
        private Button font_size_down;
        private Button font_size_up;
        private Label font_size_lbl;
        private Button black_text_btn;
        private Button red_text_btn;
        private Button yellow_text_btn;
        private Button white_text_btn;
        private Label text_colour_lbl;
        private Button black_background_btn;
        private Button blue_background_btn;
        private Button yellow_background_btn;
        private Button white_background_btn;
        private Label background_colour_lbl;
    }
}