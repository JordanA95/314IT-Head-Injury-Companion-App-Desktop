﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Head_Injury_Companion_App
{
    public partial class DailyLivingTaskHelp : Form
    {
        public DailyLivingTaskHelp()
        {
            InitializeComponent();
        }

        static public Font ChangeFontSize(Font font, float fontSize)
        {
            if (font != null)
            {
                float currentSize = font.Size;
                if (currentSize != fontSize)
                {
                    font = new Font(font.Name, fontSize,
                        font.Style, font.Unit,
                        font.GdiCharSet, font.GdiVerticalFont);
                }
            }
            return font;
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show(); //Opens the "Home" form
        }

        private void font_size_up_Click(object sender, EventArgs e)
        {
            Title.Font = ChangeFontSize(Title.Font, Title.Font.Size + 1);
            Back_btn.Font = ChangeFontSize(Back_btn.Font, Back_btn.Font.Size + 1);
            making_cup_of_tea_btn.Font = ChangeFontSize(making_cup_of_tea_btn.Font, making_cup_of_tea_btn.Font.Size + 1);
            making_sandwich_btn.Font = ChangeFontSize(making_sandwich_btn.Font, making_sandwich_btn.Font.Size + 1);
            washing_up_btn.Font = ChangeFontSize(washing_up_btn.Font, washing_up_btn.Font.Size + 1);
            brushing_teeth_btn.Font = ChangeFontSize(brushing_teeth_btn.Font, brushing_teeth_btn.Font.Size + 1);
        }

        private void font_size_down_Click(object sender, EventArgs e)
        {
            Title.Font = ChangeFontSize(Title.Font, Title.Font.Size - 1);
            Back_btn.Font = ChangeFontSize(Back_btn.Font, Back_btn.Font.Size - 1);
            making_cup_of_tea_btn.Font = ChangeFontSize(making_cup_of_tea_btn.Font, making_cup_of_tea_btn.Font.Size - 1);
            making_sandwich_btn.Font = ChangeFontSize(making_sandwich_btn.Font, making_sandwich_btn.Font.Size - 1);
            washing_up_btn.Font = ChangeFontSize(washing_up_btn.Font, washing_up_btn.Font.Size - 1);
            brushing_teeth_btn.Font = ChangeFontSize(brushing_teeth_btn.Font, brushing_teeth_btn.Font.Size - 1);
        }

        private void white_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
        }

        private void yellow_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Yellow;
        }

        private void blue_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
        }

        private void black_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Black;
        }

        private void white_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.White;
            background_colour_lbl.ForeColor = Color.White;
            text_colour_lbl.ForeColor = Color.White;
            font_size_lbl.ForeColor = Color.White;
        }

        private void yellow_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.Yellow;
            background_colour_lbl.ForeColor = Color.Yellow;
            text_colour_lbl.ForeColor = Color.Yellow;
            font_size_lbl.ForeColor = Color.Yellow;
        }

        private void red_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.Red;
            background_colour_lbl.ForeColor = Color.Red;
            text_colour_lbl.ForeColor = Color.Red;
            font_size_lbl.ForeColor = Color.Red;
        }

        private void black_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.Black;
            background_colour_lbl.ForeColor = Color.Black;
            text_colour_lbl.ForeColor = Color.Black;
            font_size_lbl.ForeColor = Color.Black;
        }

        private void making_cup_of_tea_btn_Click(object sender, EventArgs e)
        {
            making_cup_of_tea.Visible = true;
            brushing_teeth.Visible = false;
            making_sandwich.Visible = false;
            washing_up.Visible = false;
        }

        private void making_sandwich_btn_Click(object sender, EventArgs e)
        {
            making_cup_of_tea.Visible = false;
            brushing_teeth.Visible = false;
            making_sandwich.Visible = true;
            washing_up.Visible = false;
        }

        private void washing_up_btn_Click(object sender, EventArgs e)
        {
            making_cup_of_tea.Visible = false;
            brushing_teeth.Visible = false;
            making_sandwich.Visible = false;
            washing_up.Visible = true;
        }

        private void brushing_teeth_btn_Click(object sender, EventArgs e)
        {
            making_cup_of_tea.Visible = false;
            brushing_teeth.Visible = true;
            making_sandwich.Visible = false;
            washing_up.Visible = false;
        }
    }
}
