﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;

namespace Head_Injury_Companion_App
{
    public partial class MyReminders : Form
    {
        private System.Timers.Timer timer;
        public MyReminders()
        {
            InitializeComponent();

            timer = new System.Timers.Timer();
            timer.Interval = 1000;
            timer.Elapsed += Timer_Elapsed;
        }

        static public Font ChangeFontSize(Font font, float fontSize)
        {
            if (font != null)
            {
                float currentSize = font.Size;
                if (currentSize != fontSize)
                {
                    font = new Font(font.Name, fontSize,
                        font.Style, font.Unit,
                        font.GdiCharSet, font.GdiVerticalFont);
                }
            }
            return font;
        }

        private void MyReminders_Load(object sender, EventArgs e)
        {
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            timer.Start();
            MessageBox.Show("Your reminder has been set", "Reminder");
        }

        private void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            DateTime currentTime = DateTime.Now;
            DateTime userTime = dateTimePicker1.Value;
            if (currentTime.Hour == userTime.Hour && currentTime.Minute == userTime.Minute && currentTime.Second == userTime.Second)
            {
                timer.Stop();
                try
                {
                    MessageBox.Show(remindermessage.Text);
                }
                catch
                {
                    MessageBox.Show(remindermessage.Text, "Reminder!");
                }
            }
        }

        private void stopButton_Click(object sender, EventArgs e)
        {
            timer.Stop();
            MessageBox.Show("Your reminder has been canceled!", "Reminder");
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show(); //Opens the "Home" form
        }

        private void font_size_up_Click(object sender, EventArgs e)
        {
            Title.Font = ChangeFontSize(Title.Font, Title.Font.Size + 1);
            Back_btn.Font = ChangeFontSize(Back_btn.Font, Back_btn.Font.Size + 1);
            dateTimePicker1.Font = ChangeFontSize(dateTimePicker1.Font, dateTimePicker1.Font.Size + 1);
            startButton.Font = ChangeFontSize(startButton.Font, startButton.Font.Size + 1);
            stopButton.Font = ChangeFontSize(stopButton.Font, stopButton.Font.Size + 1);
        }

        private void font_size_down_Click(object sender, EventArgs e)
        {
            Title.Font = ChangeFontSize(Title.Font, Title.Font.Size - 1);
            Back_btn.Font = ChangeFontSize(Back_btn.Font, Back_btn.Font.Size - 1);
            dateTimePicker1.Font = ChangeFontSize(dateTimePicker1.Font, dateTimePicker1.Font.Size - 1);
            startButton.Font = ChangeFontSize(startButton.Font, startButton.Font.Size - 1);
            stopButton.Font = ChangeFontSize(stopButton.Font, stopButton.Font.Size - 1);
        }

        private void white_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.White;
        }

        private void yellow_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Yellow;
        }

        private void blue_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
        }

        private void black_background_btn_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Black;
        }

        private void white_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.White;
            background_colour_lbl.ForeColor = Color.White;
            text_colour_lbl.ForeColor = Color.White;
            font_size_lbl.ForeColor = Color.White;
            reminder_message_lbl.ForeColor= Color.White;
            reminder_time_lbl.ForeColor= Color.White;
        }

        private void yellow_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.Yellow;
            background_colour_lbl.ForeColor = Color.Yellow;
            text_colour_lbl.ForeColor= Color.Yellow;
            font_size_lbl.ForeColor = Color.Yellow;
            reminder_message_lbl.ForeColor = Color.Yellow;
            reminder_time_lbl.ForeColor = Color.Yellow;
        }

        private void red_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.Red;
            background_colour_lbl.ForeColor = Color.Red;
            text_colour_lbl.ForeColor = Color.Red;
            font_size_lbl.ForeColor = Color.Red;
            reminder_message_lbl.ForeColor = Color.Red;
            reminder_time_lbl.ForeColor = Color.Red;
        }

        private void black_text_btn_Click(object sender, EventArgs e)
        {
            Title.ForeColor = Color.Black;
            background_colour_lbl.ForeColor = Color.Black;
            text_colour_lbl.ForeColor = Color.Black;
            font_size_lbl.ForeColor = Color.Black;
            reminder_message_lbl.ForeColor = Color.Black;
            reminder_time_lbl.ForeColor = Color.Black;
        }
    }
}
