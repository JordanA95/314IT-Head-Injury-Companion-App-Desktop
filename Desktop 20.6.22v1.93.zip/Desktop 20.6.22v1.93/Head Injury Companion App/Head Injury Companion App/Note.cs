﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Head_Injury_Companion_App
{
    //C# Note Class for specifying all fields that appear in Notes table in the database.
    public class Note
    {
        public int ID { get; set; }
        public string NoteContent { get; set; }
    }
}
