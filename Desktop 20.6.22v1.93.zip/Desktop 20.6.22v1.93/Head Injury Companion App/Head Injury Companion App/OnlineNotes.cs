﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Head_Injury_Companion_App
{
    public partial class OnlineNotes : Form
    {
        //Initialise DbConn for database connection
        DbConn dbConn = new DbConn();
        public OnlineNotes()
        {
            InitializeComponent();
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            MyNotes MyNotes = new MyNotes();
            MyNotes.Show(); //Opens the "My Notes" form
        }

        private void updateselectednotebtn_Click(object sender, EventArgs e)
        {
            //When updateselectedbtn button clicked, set the value of the Note class variables to the value of the corresponding textbox.
            //Then run UpdateNote stored procedure. Then repopulate the DataGridiew by using the selectAllNotes stored procedure.
            Note note = new Note();
            note.NoteContent = onlinenote_txb.Text;
            dbConn.UpdateNote(note);
            onlinenotedgv.DataSource = dbConn.selectAllNotes();
            int index = Int32.Parse(onlinenotedgv.SelectedCells[0].Value.ToString());

            //Enable all textboxes and relevant buttons.
            onlinenote_txb.Enabled = true;

            updateselectednotebtn.Enabled = false;
            saveselectednotebtn.Enabled = true;
            deleteselectednotebtn.Enabled = false;
            addnewnotebtn.Enabled = false;
            savenewnotebtn.Enabled = false;
            refreshnotebtn.Enabled = false;
            cancelbtn.Enabled = true;
            //Set statuslbl label value to inform the user that they are updating a note.
            statuslbl.Text = "You are updating an existing note";
        }

        private void addnewnotebtn_Click(object sender, EventArgs e)
        {
            //Clear and enable the textboxes and relevant buttons ready for adding a new note.
            onlinenote_txb.Enabled = true;

            savenewnotebtn.Enabled = true;
            updateselectednotebtn.Enabled = false;
            saveselectednotebtn.Enabled = false;
            deleteselectednotebtn.Enabled = false;
            addnewnotebtn.Enabled = false;
            savenewnotebtn.Enabled = true;
            refreshnotebtn.Enabled = false;
            cancelbtn.Enabled = true;

            onlinenote_txb.Text = string.Empty;
            //Set the value of statuslbl label to inform the user that they are adding a new note.
            statuslbl.Text = "You are adding a new note";
        }

        private void saveselectednotebtn_Click(object sender, EventArgs e)
        {
            //Preare for saving a note to the database by setting the values of Note class to the values of the textboxes. Disable all buttons except for Update and AddNew. Then clear the textbox.
            int index = Int32.Parse(onlinenotedgv.SelectedCells[0].Value.ToString());
            Note note = new Note();
            note.ID = index;
            note.NoteContent = onlinenote_txb.Text;
            //Run the UpdateNote stored procedure.
            dbConn.UpdateNote(note);
            //Repopulate the values in onlinenotedgv data grid view using the selectAllNotes stored procedure.
            onlinenotedgv.DataSource = dbConn.selectAllNotes();

            //Disable all textboxes.
            onlinenote_txb.Enabled = false;

            //Disable all buttons except for refresh button to prompt the user to click refresh.
            savenewnotebtn.Enabled = false;
            updateselectednotebtn.Enabled = false;
            saveselectednotebtn.Enabled = false;
            deleteselectednotebtn.Enabled = false;
            addnewnotebtn.Enabled = false;
            savenewnotebtn.Enabled = false;
            refreshnotebtn.Enabled = true;
            cancelbtn.Enabled = false;

            //Empty the value of all textboxes and set the statuslbl label value to -.
            onlinenote_txb.Text = string.Empty;
            statuslbl.Text = "-";
        }

        private void savenewnotebtn_Click(object sender, EventArgs e)
        {
            //When savenewbtn button clicked, set the values of Note class variables to the value of the corresponding textbox. Then run the InsertNote stored procedure.
            Note note = new Note();
            note.NoteContent = onlinenote_txb.Text;
            dbConn.InsertNote(note);

            ///Disable all textboxes and buttons except for refeshnotebtn button.
            onlinenote_txb.Enabled = false;

            savenewnotebtn.Enabled = false;
            updateselectednotebtn.Enabled = false;
            saveselectednotebtn.Enabled = false;
            deleteselectednotebtn.Enabled = false;
            addnewnotebtn.Enabled = false;
            savenewnotebtn.Enabled = false;
            refreshnotebtn.Enabled = true;
            cancelbtn.Enabled = false;

            //Empty the value of onlinenote_txb textbox.
            onlinenote_txb.Text = string.Empty;

            // Code to auto-refresh table.
            onlinenotedgv.DataSource = dbConn.selectAllNotes();

            //Set the value of the statuslbl to -
            statuslbl.Text = "-";
        }

        private void deleteselectednotebtn_Click(object sender, EventArgs e)
        {
            //Run the DeleteNote stored procedure after a confirmation message is displayed and yes is selected.
            string message = "Are you sure?";
            string caption = "Are you sure you want to delete the selected note?";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            result = MessageBox.Show(message, caption, buttons);
            if (result == DialogResult.Yes)
            {
                dbConn.DeleteNote(Int32.Parse(onlinenotedgv.SelectedCells[0].Value.ToString()));

                onlinenotedgv.DataSource = dbConn.selectAllNotes();
            }
            statuslbl.Text = "-";
        }

        private void refreshnotebtn_Click(object sender, EventArgs e)
        {
            onlinenotedgv.DataSource = dbConn.selectAllNotes();
            updateselectednotebtn.Enabled = true;
            addnewnotebtn.Enabled = true;
            deleteselectednotebtn.Enabled = true;
            refreshnotebtn.Enabled = true;
            //When Refresh button presed, initialise selectAllNotes stored procedure to get all records in the user_notestbl table of the database.
        }

        private void cancelbtn_Click(object sender, EventArgs e)
        {
            //Cancel the adding or updating of a note by clearing the value of the textbox and resetting the buttons enabled.
            onlinenote_txb.Text = string.Empty;

            savenewnotebtn.Enabled = true;
            updateselectednotebtn.Enabled = true;
            saveselectednotebtn.Enabled = false;
            deleteselectednotebtn.Enabled = true;
            addnewnotebtn.Enabled = true;
            savenewnotebtn.Enabled = false;
            refreshnotebtn.Enabled = true;
            statuslbl.Text = "-";
        }
    }
}
