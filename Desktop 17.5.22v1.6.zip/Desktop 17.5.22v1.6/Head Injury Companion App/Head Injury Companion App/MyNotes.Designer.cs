﻿namespace Head_Injury_Companion_App
{
    partial class MyNotes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MyNotes));
            this.Title = new System.Windows.Forms.Label();
            this.Back_btn = new System.Windows.Forms.Button();
            this.new_btn = new System.Windows.Forms.Button();
            this.notepad = new System.Windows.Forms.PictureBox();
            this.open_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            this.notearea = new System.Windows.Forms.TextBox();
            this.backlabel = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.font_size_down = new System.Windows.Forms.Button();
            this.font_size_up = new System.Windows.Forms.Button();
            this.font_size_lbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.notepad)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(441, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(165, 38);
            this.Title.TabIndex = 1;
            this.Title.Text = "My Notes";
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.Color.Red;
            this.Back_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Back_btn.ForeColor = System.Drawing.Color.White;
            this.Back_btn.Location = new System.Drawing.Point(12, 12);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(120, 64);
            this.Back_btn.TabIndex = 10;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = false;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // new_btn
            // 
            this.new_btn.BackColor = System.Drawing.Color.Red;
            this.new_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.new_btn.ForeColor = System.Drawing.Color.White;
            this.new_btn.Location = new System.Drawing.Point(78, 96);
            this.new_btn.Name = "new_btn";
            this.new_btn.Size = new System.Drawing.Size(166, 48);
            this.new_btn.TabIndex = 11;
            this.new_btn.Text = "New";
            this.new_btn.UseVisualStyleBackColor = false;
            this.new_btn.Click += new System.EventHandler(this.new_btn_Click);
            // 
            // notepad
            // 
            this.notepad.Image = ((System.Drawing.Image)(resources.GetObject("notepad.Image")));
            this.notepad.Location = new System.Drawing.Point(987, 12);
            this.notepad.Name = "notepad";
            this.notepad.Size = new System.Drawing.Size(126, 114);
            this.notepad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.notepad.TabIndex = 15;
            this.notepad.TabStop = false;
            // 
            // open_btn
            // 
            this.open_btn.BackColor = System.Drawing.Color.Red;
            this.open_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.open_btn.ForeColor = System.Drawing.Color.White;
            this.open_btn.Location = new System.Drawing.Point(250, 96);
            this.open_btn.Name = "open_btn";
            this.open_btn.Size = new System.Drawing.Size(166, 48);
            this.open_btn.TabIndex = 16;
            this.open_btn.Text = "Open";
            this.open_btn.UseVisualStyleBackColor = false;
            this.open_btn.Click += new System.EventHandler(this.open_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.BackColor = System.Drawing.Color.Red;
            this.save_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.save_btn.ForeColor = System.Drawing.Color.White;
            this.save_btn.Location = new System.Drawing.Point(422, 96);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(166, 48);
            this.save_btn.TabIndex = 17;
            this.save_btn.Text = "Save";
            this.save_btn.UseVisualStyleBackColor = false;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // notearea
            // 
            this.notearea.Location = new System.Drawing.Point(12, 165);
            this.notearea.Multiline = true;
            this.notearea.Name = "notearea";
            this.notearea.Size = new System.Drawing.Size(1101, 479);
            this.notearea.TabIndex = 19;
            this.notearea.Visible = false;
            // 
            // backlabel
            // 
            this.backlabel.AutoSize = true;
            this.backlabel.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.backlabel.ForeColor = System.Drawing.Color.White;
            this.backlabel.Location = new System.Drawing.Point(45, 377);
            this.backlabel.Name = "backlabel";
            this.backlabel.Size = new System.Drawing.Size(1053, 32);
            this.backlabel.TabIndex = 20;
            this.backlabel.Text = "No Note loaded. Click \"New\" to create a new note or \"Open\" to load an existing no" +
    "te.";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // font_size_down
            // 
            this.font_size_down.BackColor = System.Drawing.Color.Red;
            this.font_size_down.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_down.ForeColor = System.Drawing.Color.White;
            this.font_size_down.Location = new System.Drawing.Point(1075, 650);
            this.font_size_down.Name = "font_size_down";
            this.font_size_down.Size = new System.Drawing.Size(38, 47);
            this.font_size_down.TabIndex = 23;
            this.font_size_down.Text = "-";
            this.font_size_down.UseVisualStyleBackColor = false;
            this.font_size_down.Click += new System.EventHandler(this.font_size_down_Click);
            // 
            // font_size_up
            // 
            this.font_size_up.BackColor = System.Drawing.Color.Red;
            this.font_size_up.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_up.ForeColor = System.Drawing.Color.White;
            this.font_size_up.Location = new System.Drawing.Point(1031, 650);
            this.font_size_up.Name = "font_size_up";
            this.font_size_up.Size = new System.Drawing.Size(38, 47);
            this.font_size_up.TabIndex = 22;
            this.font_size_up.Text = "+";
            this.font_size_up.UseVisualStyleBackColor = false;
            this.font_size_up.Click += new System.EventHandler(this.font_size_up_Click);
            // 
            // font_size_lbl
            // 
            this.font_size_lbl.AutoSize = true;
            this.font_size_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_lbl.ForeColor = System.Drawing.Color.White;
            this.font_size_lbl.Location = new System.Drawing.Point(909, 659);
            this.font_size_lbl.Name = "font_size_lbl";
            this.font_size_lbl.Size = new System.Drawing.Size(116, 33);
            this.font_size_lbl.TabIndex = 21;
            this.font_size_lbl.Text = "Font Size";
            // 
            // MyNotes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1125, 701);
            this.Controls.Add(this.font_size_down);
            this.Controls.Add(this.font_size_up);
            this.Controls.Add(this.font_size_lbl);
            this.Controls.Add(this.notearea);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.open_btn);
            this.Controls.Add(this.notepad);
            this.Controls.Add(this.new_btn);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.backlabel);
            this.Name = "MyNotes";
            this.Text = "MyNotes";
            ((System.ComponentModel.ISupportInitialize)(this.notepad)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Title;
        private Button Back_btn;
        private Button new_btn;
        private PictureBox notepad;
        private Button open_btn;
        private Button save_btn;
        private TextBox notearea;
        private Label backlabel;
        private SaveFileDialog saveFileDialog1;
        private FolderBrowserDialog folderBrowserDialog1;
        private OpenFileDialog openFileDialog1;
        private Button font_size_down;
        private Button font_size_up;
        private Label font_size_lbl;
    }
}