﻿namespace Head_Injury_Companion_App
{
    partial class ApplicationHelpAndSupport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ApplicationHelpAndSupport));
            this.Title = new System.Windows.Forms.Label();
            this.apphelp = new System.Windows.Forms.PictureBox();
            this.Back_btn = new System.Windows.Forms.Button();
            this.faqweb = new Microsoft.Web.WebView2.WinForms.WebView2();
            this.font_size_down = new System.Windows.Forms.Button();
            this.font_size_up = new System.Windows.Forms.Button();
            this.font_size_lbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.apphelp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.faqweb)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(287, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(492, 38);
            this.Title.TabIndex = 2;
            this.Title.Text = "Application Help and Support";
            // 
            // apphelp
            // 
            this.apphelp.Image = ((System.Drawing.Image)(resources.GetObject("apphelp.Image")));
            this.apphelp.Location = new System.Drawing.Point(989, 12);
            this.apphelp.Name = "apphelp";
            this.apphelp.Size = new System.Drawing.Size(126, 114);
            this.apphelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.apphelp.TabIndex = 12;
            this.apphelp.TabStop = false;
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.Color.Red;
            this.Back_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Back_btn.ForeColor = System.Drawing.Color.White;
            this.Back_btn.Location = new System.Drawing.Point(12, 12);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(120, 64);
            this.Back_btn.TabIndex = 14;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = false;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // faqweb
            // 
            this.faqweb.AllowExternalDrop = true;
            this.faqweb.CreationProperties = null;
            this.faqweb.DefaultBackgroundColor = System.Drawing.Color.White;
            this.faqweb.Location = new System.Drawing.Point(12, 133);
            this.faqweb.Name = "faqweb";
            this.faqweb.Size = new System.Drawing.Size(1102, 444);
            this.faqweb.Source = new System.Uri("https://adamso10.wixsite.com/head-injury-app-faq", System.UriKind.Absolute);
            this.faqweb.TabIndex = 15;
            this.faqweb.ZoomFactor = 1D;
            // 
            // font_size_down
            // 
            this.font_size_down.BackColor = System.Drawing.Color.Red;
            this.font_size_down.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_down.ForeColor = System.Drawing.Color.White;
            this.font_size_down.Location = new System.Drawing.Point(1077, 644);
            this.font_size_down.Name = "font_size_down";
            this.font_size_down.Size = new System.Drawing.Size(38, 47);
            this.font_size_down.TabIndex = 29;
            this.font_size_down.Text = "-";
            this.font_size_down.UseVisualStyleBackColor = false;
            this.font_size_down.Click += new System.EventHandler(this.font_size_down_Click);
            // 
            // font_size_up
            // 
            this.font_size_up.BackColor = System.Drawing.Color.Red;
            this.font_size_up.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_up.ForeColor = System.Drawing.Color.White;
            this.font_size_up.Location = new System.Drawing.Point(1033, 644);
            this.font_size_up.Name = "font_size_up";
            this.font_size_up.Size = new System.Drawing.Size(38, 47);
            this.font_size_up.TabIndex = 28;
            this.font_size_up.Text = "+";
            this.font_size_up.UseVisualStyleBackColor = false;
            this.font_size_up.Click += new System.EventHandler(this.font_size_up_Click);
            // 
            // font_size_lbl
            // 
            this.font_size_lbl.AutoSize = true;
            this.font_size_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_lbl.ForeColor = System.Drawing.Color.White;
            this.font_size_lbl.Location = new System.Drawing.Point(911, 653);
            this.font_size_lbl.Name = "font_size_lbl";
            this.font_size_lbl.Size = new System.Drawing.Size(116, 33);
            this.font_size_lbl.TabIndex = 27;
            this.font_size_lbl.Text = "Font Size";
            // 
            // ApplicationHelpAndSupport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1127, 703);
            this.Controls.Add(this.font_size_down);
            this.Controls.Add(this.font_size_up);
            this.Controls.Add(this.font_size_lbl);
            this.Controls.Add(this.faqweb);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.apphelp);
            this.Controls.Add(this.Title);
            this.Name = "ApplicationHelpAndSupport";
            this.Text = "ApplicationHelpAndSupport";
            ((System.ComponentModel.ISupportInitialize)(this.apphelp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.faqweb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Title;
        private PictureBox apphelp;
        private Button Back_btn;
        private Microsoft.Web.WebView2.WinForms.WebView2 faqweb;
        private Button font_size_down;
        private Button font_size_up;
        private Label font_size_lbl;
    }
}