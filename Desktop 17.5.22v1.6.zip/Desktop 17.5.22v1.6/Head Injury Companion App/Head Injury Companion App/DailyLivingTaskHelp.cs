﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Head_Injury_Companion_App
{
    public partial class DailyLivingTaskHelp : Form
    {
        public DailyLivingTaskHelp()
        {
            InitializeComponent();
        }

        static public Font ChangeFontSize(Font font, float fontSize)
        {
            if (font != null)
            {
                float currentSize = font.Size;
                if (currentSize != fontSize)
                {
                    font = new Font(font.Name, fontSize,
                        font.Style, font.Unit,
                        font.GdiCharSet, font.GdiVerticalFont);
                }
            }
            return font;
        }

        private void Back_btn_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show(); //Opens the "Home" form
        }

        private void font_size_up_Click(object sender, EventArgs e)
        {
            Title.Font = ChangeFontSize(Title.Font, Title.Font.Size + 1);
            Back_btn.Font = ChangeFontSize(Back_btn.Font, Back_btn.Font.Size + 1);
            making_cup_of_tea_btn.Font = ChangeFontSize(making_cup_of_tea_btn.Font, making_cup_of_tea_btn.Font.Size + 1);
            making_sandwich_btn.Font = ChangeFontSize(making_sandwich_btn.Font, making_sandwich_btn.Font.Size + 1);
            washing_up_btn.Font = ChangeFontSize(washing_up_btn.Font, washing_up_btn.Font.Size + 1);
            brushing_teeth_btn.Font = ChangeFontSize(brushing_teeth_btn.Font, brushing_teeth_btn.Font.Size + 1);
        }

        private void font_size_down_Click(object sender, EventArgs e)
        {
            Title.Font = ChangeFontSize(Title.Font, Title.Font.Size - 1);
            Back_btn.Font = ChangeFontSize(Back_btn.Font, Back_btn.Font.Size - 1);
            making_cup_of_tea_btn.Font = ChangeFontSize(making_cup_of_tea_btn.Font, making_cup_of_tea_btn.Font.Size - 1);
            making_sandwich_btn.Font = ChangeFontSize(making_sandwich_btn.Font, making_sandwich_btn.Font.Size - 1);
            washing_up_btn.Font = ChangeFontSize(washing_up_btn.Font, washing_up_btn.Font.Size - 1);
            brushing_teeth_btn.Font = ChangeFontSize(brushing_teeth_btn.Font, brushing_teeth_btn.Font.Size - 1);
        }
    }
}
