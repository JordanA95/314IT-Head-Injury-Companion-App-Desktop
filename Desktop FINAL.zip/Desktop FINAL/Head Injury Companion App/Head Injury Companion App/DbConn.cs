﻿using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySqlConnector;

namespace Head_Injury_Companion_App
{
    public class DbConn
    {
        //Database connection string for connecting to the headapp AWS Database instance.
        private string connstring = "server=headapp.cub20pif3hru.us-east-1.rds.amazonaws.com; Port=3306; Database=usernotes; User ID=admin; Password=headinjuryapp";

        //Stored procedure for getting all Notes stored in the database.
        public DataTable selectAllNotes()
        {
            using (var conn = new MySqlConnection(connstring))
            {
                conn.Open();
                DataTable userNotesDt = new DataTable();
                List<Note> notes = new List<Note>();
                using (var cmd = new MySqlCommand("CALL selectAllNotes();", conn))

                using (var reader = cmd.ExecuteReader())
                    while (reader.Read())
                    {
                        notes.Add(new Note
                        {
                            ID = reader.GetInt32(0),
                            NoteContent = reader.GetString(1),
                        });
                    }
                userNotesDt.Columns.Add("ID");
                userNotesDt.Columns.Add("UserNote");

                foreach (var item in notes)
                {
                    var row = userNotesDt.NewRow();

                    row["ID"] = item.ID;
                    row["UserNote"] = item.NoteContent;

                    userNotesDt.Rows.Add(row);
                }
                return userNotesDt;
            }
        }

        //Stored procedure for inserting a new Note into the database, using asynchronous programming commands async and await to run this procedure in a different thread to the main application.
        public async void InsertNote(Note note)
        {
            using (var conn = new MySqlConnection(connstring))
            {
                await conn.OpenAsync();
                using (var cmd = new MySqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "CALL insertNote(@p1);";
                    cmd.Parameters.AddWithValue("p1", note.NoteContent);
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }

        //Stored procedure for updating a Note in the database, using asynchronous programming commands async and await to run this procedure in a different thread to the main application.
        public async void UpdateNote(Note note)
        {
            using (var conn = new MySqlConnection(connstring))
            {
                await conn.OpenAsync();
                using (var cmd = new MySqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "CALL updateNote(@p1, @p2);";
                    cmd.Parameters.AddWithValue("p1", note.ID);
                    cmd.Parameters.AddWithValue("p2", note.NoteContent);
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }

        //Stored procedure for deleting a Note from the database using the id value, using asynchronous programming commands async and await to run this procedure in a different thread to the main application.
        public async void DeleteNote(int ID)
        {
            using (var conn = new MySqlConnection(connstring))
            {
                await conn.OpenAsync();
                using (var cmd = new MySqlCommand())
                {
                    cmd.Connection = conn;
                    cmd.CommandText = "CALL deleteNote(@p1);";
                    cmd.Parameters.AddWithValue("p1", ID);
                    await cmd.ExecuteNonQueryAsync();
                }
            }
        }
    }
}
