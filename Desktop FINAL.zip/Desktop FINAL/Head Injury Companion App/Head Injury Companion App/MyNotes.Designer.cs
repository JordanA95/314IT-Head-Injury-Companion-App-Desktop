﻿namespace Head_Injury_Companion_App
{
    partial class MyNotes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MyNotes));
            this.Title = new System.Windows.Forms.Label();
            this.Back_btn = new System.Windows.Forms.Button();
            this.new_btn = new System.Windows.Forms.Button();
            this.notepad = new System.Windows.Forms.PictureBox();
            this.open_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            this.notearea = new System.Windows.Forms.TextBox();
            this.backlabel = new System.Windows.Forms.Label();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.font_size_down = new System.Windows.Forms.Button();
            this.font_size_up = new System.Windows.Forms.Button();
            this.font_size_lbl = new System.Windows.Forms.Label();
            this.black_text_btn = new System.Windows.Forms.Button();
            this.red_text_btn = new System.Windows.Forms.Button();
            this.yellow_text_btn = new System.Windows.Forms.Button();
            this.white_text_btn = new System.Windows.Forms.Button();
            this.text_colour_lbl = new System.Windows.Forms.Label();
            this.black_background_btn = new System.Windows.Forms.Button();
            this.blue_background_btn = new System.Windows.Forms.Button();
            this.yellow_background_btn = new System.Windows.Forms.Button();
            this.white_background_btn = new System.Windows.Forms.Button();
            this.background_colour_lbl = new System.Windows.Forms.Label();
            this.black_note_background_btn = new System.Windows.Forms.Button();
            this.blue_note_background_btn = new System.Windows.Forms.Button();
            this.yellow_note_backgrond_btn = new System.Windows.Forms.Button();
            this.white_note_background_btn = new System.Windows.Forms.Button();
            this.note_background_colour_lbl = new System.Windows.Forms.Label();
            this.black_note_text_btn = new System.Windows.Forms.Button();
            this.red_note_text_btn = new System.Windows.Forms.Button();
            this.yellow_note_text_btn = new System.Windows.Forms.Button();
            this.white_note_text_btn = new System.Windows.Forms.Button();
            this.note_text_colour_lbl = new System.Windows.Forms.Label();
            this.online_notes_btn = new System.Windows.Forms.Button();
            this.font_size_reset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.notepad)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(441, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(165, 38);
            this.Title.TabIndex = 1;
            this.Title.Text = "My Notes";
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.Color.Red;
            this.Back_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Back_btn.ForeColor = System.Drawing.Color.White;
            this.Back_btn.Location = new System.Drawing.Point(12, 12);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(120, 64);
            this.Back_btn.TabIndex = 10;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = false;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // new_btn
            // 
            this.new_btn.BackColor = System.Drawing.Color.Red;
            this.new_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.new_btn.ForeColor = System.Drawing.Color.White;
            this.new_btn.Location = new System.Drawing.Point(78, 96);
            this.new_btn.Name = "new_btn";
            this.new_btn.Size = new System.Drawing.Size(166, 48);
            this.new_btn.TabIndex = 11;
            this.new_btn.Text = "New";
            this.new_btn.UseVisualStyleBackColor = false;
            this.new_btn.Click += new System.EventHandler(this.new_btn_Click);
            // 
            // notepad
            // 
            this.notepad.Image = ((System.Drawing.Image)(resources.GetObject("notepad.Image")));
            this.notepad.Location = new System.Drawing.Point(987, 12);
            this.notepad.Name = "notepad";
            this.notepad.Size = new System.Drawing.Size(126, 114);
            this.notepad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.notepad.TabIndex = 15;
            this.notepad.TabStop = false;
            // 
            // open_btn
            // 
            this.open_btn.BackColor = System.Drawing.Color.Red;
            this.open_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.open_btn.ForeColor = System.Drawing.Color.White;
            this.open_btn.Location = new System.Drawing.Point(250, 96);
            this.open_btn.Name = "open_btn";
            this.open_btn.Size = new System.Drawing.Size(166, 48);
            this.open_btn.TabIndex = 16;
            this.open_btn.Text = "Open";
            this.open_btn.UseVisualStyleBackColor = false;
            this.open_btn.Click += new System.EventHandler(this.open_btn_Click);
            // 
            // save_btn
            // 
            this.save_btn.BackColor = System.Drawing.Color.Red;
            this.save_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.save_btn.ForeColor = System.Drawing.Color.White;
            this.save_btn.Location = new System.Drawing.Point(422, 96);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(166, 48);
            this.save_btn.TabIndex = 17;
            this.save_btn.Text = "Save";
            this.save_btn.UseVisualStyleBackColor = false;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // notearea
            // 
            this.notearea.Location = new System.Drawing.Point(12, 165);
            this.notearea.Multiline = true;
            this.notearea.Name = "notearea";
            this.notearea.Size = new System.Drawing.Size(1101, 406);
            this.notearea.TabIndex = 19;
            this.notearea.Visible = false;
            // 
            // backlabel
            // 
            this.backlabel.AutoSize = true;
            this.backlabel.Font = new System.Drawing.Font("Arial", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.backlabel.ForeColor = System.Drawing.Color.White;
            this.backlabel.Location = new System.Drawing.Point(45, 377);
            this.backlabel.Name = "backlabel";
            this.backlabel.Size = new System.Drawing.Size(1053, 32);
            this.backlabel.TabIndex = 20;
            this.backlabel.Text = "No Note loaded. Click \"New\" to create a new note or \"Open\" to load an existing no" +
    "te.";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // font_size_down
            // 
            this.font_size_down.BackColor = System.Drawing.Color.Red;
            this.font_size_down.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_down.ForeColor = System.Drawing.Color.White;
            this.font_size_down.Location = new System.Drawing.Point(1031, 651);
            this.font_size_down.Name = "font_size_down";
            this.font_size_down.Size = new System.Drawing.Size(38, 47);
            this.font_size_down.TabIndex = 23;
            this.font_size_down.Text = "-";
            this.font_size_down.UseVisualStyleBackColor = false;
            this.font_size_down.Click += new System.EventHandler(this.font_size_down_Click);
            // 
            // font_size_up
            // 
            this.font_size_up.BackColor = System.Drawing.Color.Red;
            this.font_size_up.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_up.ForeColor = System.Drawing.Color.White;
            this.font_size_up.Location = new System.Drawing.Point(987, 651);
            this.font_size_up.Name = "font_size_up";
            this.font_size_up.Size = new System.Drawing.Size(38, 47);
            this.font_size_up.TabIndex = 22;
            this.font_size_up.Text = "+";
            this.font_size_up.UseVisualStyleBackColor = false;
            this.font_size_up.Click += new System.EventHandler(this.font_size_up_Click);
            // 
            // font_size_lbl
            // 
            this.font_size_lbl.AutoSize = true;
            this.font_size_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_lbl.ForeColor = System.Drawing.Color.White;
            this.font_size_lbl.Location = new System.Drawing.Point(865, 660);
            this.font_size_lbl.Name = "font_size_lbl";
            this.font_size_lbl.Size = new System.Drawing.Size(116, 33);
            this.font_size_lbl.TabIndex = 21;
            this.font_size_lbl.Text = "Font Size";
            // 
            // black_text_btn
            // 
            this.black_text_btn.BackColor = System.Drawing.Color.Black;
            this.black_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.black_text_btn.ForeColor = System.Drawing.Color.White;
            this.black_text_btn.Location = new System.Drawing.Point(736, 651);
            this.black_text_btn.Name = "black_text_btn";
            this.black_text_btn.Size = new System.Drawing.Size(38, 47);
            this.black_text_btn.TabIndex = 38;
            this.black_text_btn.UseVisualStyleBackColor = false;
            this.black_text_btn.Click += new System.EventHandler(this.black_text_btn_Click);
            // 
            // red_text_btn
            // 
            this.red_text_btn.BackColor = System.Drawing.Color.Red;
            this.red_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.red_text_btn.ForeColor = System.Drawing.Color.White;
            this.red_text_btn.Location = new System.Drawing.Point(692, 650);
            this.red_text_btn.Name = "red_text_btn";
            this.red_text_btn.Size = new System.Drawing.Size(38, 47);
            this.red_text_btn.TabIndex = 37;
            this.red_text_btn.UseVisualStyleBackColor = false;
            this.red_text_btn.Click += new System.EventHandler(this.red_text_btn_Click);
            // 
            // yellow_text_btn
            // 
            this.yellow_text_btn.BackColor = System.Drawing.Color.Yellow;
            this.yellow_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yellow_text_btn.ForeColor = System.Drawing.Color.White;
            this.yellow_text_btn.Location = new System.Drawing.Point(648, 650);
            this.yellow_text_btn.Name = "yellow_text_btn";
            this.yellow_text_btn.Size = new System.Drawing.Size(38, 47);
            this.yellow_text_btn.TabIndex = 36;
            this.yellow_text_btn.UseVisualStyleBackColor = false;
            this.yellow_text_btn.Click += new System.EventHandler(this.yellow_text_btn_Click);
            // 
            // white_text_btn
            // 
            this.white_text_btn.BackColor = System.Drawing.Color.White;
            this.white_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.white_text_btn.ForeColor = System.Drawing.Color.White;
            this.white_text_btn.Location = new System.Drawing.Point(604, 651);
            this.white_text_btn.Name = "white_text_btn";
            this.white_text_btn.Size = new System.Drawing.Size(38, 47);
            this.white_text_btn.TabIndex = 35;
            this.white_text_btn.UseVisualStyleBackColor = false;
            this.white_text_btn.Click += new System.EventHandler(this.white_text_btn_Click);
            // 
            // text_colour_lbl
            // 
            this.text_colour_lbl.AutoSize = true;
            this.text_colour_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.text_colour_lbl.ForeColor = System.Drawing.Color.White;
            this.text_colour_lbl.Location = new System.Drawing.Point(455, 660);
            this.text_colour_lbl.Name = "text_colour_lbl";
            this.text_colour_lbl.Size = new System.Drawing.Size(143, 33);
            this.text_colour_lbl.TabIndex = 34;
            this.text_colour_lbl.Text = "Text Colour";
            // 
            // black_background_btn
            // 
            this.black_background_btn.BackColor = System.Drawing.Color.Black;
            this.black_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.black_background_btn.ForeColor = System.Drawing.Color.White;
            this.black_background_btn.Location = new System.Drawing.Point(382, 651);
            this.black_background_btn.Name = "black_background_btn";
            this.black_background_btn.Size = new System.Drawing.Size(38, 47);
            this.black_background_btn.TabIndex = 33;
            this.black_background_btn.UseVisualStyleBackColor = false;
            this.black_background_btn.Click += new System.EventHandler(this.black_background_btn_Click);
            // 
            // blue_background_btn
            // 
            this.blue_background_btn.BackColor = System.Drawing.Color.Blue;
            this.blue_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.blue_background_btn.ForeColor = System.Drawing.Color.White;
            this.blue_background_btn.Location = new System.Drawing.Point(338, 650);
            this.blue_background_btn.Name = "blue_background_btn";
            this.blue_background_btn.Size = new System.Drawing.Size(38, 47);
            this.blue_background_btn.TabIndex = 32;
            this.blue_background_btn.UseVisualStyleBackColor = false;
            this.blue_background_btn.Click += new System.EventHandler(this.blue_background_btn_Click);
            // 
            // yellow_background_btn
            // 
            this.yellow_background_btn.BackColor = System.Drawing.Color.Yellow;
            this.yellow_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yellow_background_btn.ForeColor = System.Drawing.Color.White;
            this.yellow_background_btn.Location = new System.Drawing.Point(294, 650);
            this.yellow_background_btn.Name = "yellow_background_btn";
            this.yellow_background_btn.Size = new System.Drawing.Size(38, 47);
            this.yellow_background_btn.TabIndex = 31;
            this.yellow_background_btn.UseVisualStyleBackColor = false;
            this.yellow_background_btn.Click += new System.EventHandler(this.yellow_background_btn_Click);
            // 
            // white_background_btn
            // 
            this.white_background_btn.BackColor = System.Drawing.Color.White;
            this.white_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.white_background_btn.ForeColor = System.Drawing.Color.White;
            this.white_background_btn.Location = new System.Drawing.Point(250, 651);
            this.white_background_btn.Name = "white_background_btn";
            this.white_background_btn.Size = new System.Drawing.Size(38, 47);
            this.white_background_btn.TabIndex = 30;
            this.white_background_btn.UseVisualStyleBackColor = false;
            this.white_background_btn.Click += new System.EventHandler(this.white_background_btn_Click);
            // 
            // background_colour_lbl
            // 
            this.background_colour_lbl.AutoSize = true;
            this.background_colour_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.background_colour_lbl.ForeColor = System.Drawing.Color.White;
            this.background_colour_lbl.Location = new System.Drawing.Point(14, 659);
            this.background_colour_lbl.Name = "background_colour_lbl";
            this.background_colour_lbl.Size = new System.Drawing.Size(230, 33);
            this.background_colour_lbl.TabIndex = 29;
            this.background_colour_lbl.Text = "Background Colour";
            // 
            // black_note_background_btn
            // 
            this.black_note_background_btn.BackColor = System.Drawing.Color.Black;
            this.black_note_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.black_note_background_btn.ForeColor = System.Drawing.Color.White;
            this.black_note_background_btn.Location = new System.Drawing.Point(382, 578);
            this.black_note_background_btn.Name = "black_note_background_btn";
            this.black_note_background_btn.Size = new System.Drawing.Size(38, 47);
            this.black_note_background_btn.TabIndex = 43;
            this.black_note_background_btn.UseVisualStyleBackColor = false;
            this.black_note_background_btn.Click += new System.EventHandler(this.black_note_background_btn_Click);
            // 
            // blue_note_background_btn
            // 
            this.blue_note_background_btn.BackColor = System.Drawing.Color.Blue;
            this.blue_note_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.blue_note_background_btn.ForeColor = System.Drawing.Color.White;
            this.blue_note_background_btn.Location = new System.Drawing.Point(338, 577);
            this.blue_note_background_btn.Name = "blue_note_background_btn";
            this.blue_note_background_btn.Size = new System.Drawing.Size(38, 47);
            this.blue_note_background_btn.TabIndex = 42;
            this.blue_note_background_btn.UseVisualStyleBackColor = false;
            this.blue_note_background_btn.Click += new System.EventHandler(this.blue_note_background_btn_Click);
            // 
            // yellow_note_backgrond_btn
            // 
            this.yellow_note_backgrond_btn.BackColor = System.Drawing.Color.Yellow;
            this.yellow_note_backgrond_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yellow_note_backgrond_btn.ForeColor = System.Drawing.Color.White;
            this.yellow_note_backgrond_btn.Location = new System.Drawing.Point(294, 577);
            this.yellow_note_backgrond_btn.Name = "yellow_note_backgrond_btn";
            this.yellow_note_backgrond_btn.Size = new System.Drawing.Size(38, 47);
            this.yellow_note_backgrond_btn.TabIndex = 41;
            this.yellow_note_backgrond_btn.UseVisualStyleBackColor = false;
            this.yellow_note_backgrond_btn.Click += new System.EventHandler(this.yellow_note_backgrond_btn_Click);
            // 
            // white_note_background_btn
            // 
            this.white_note_background_btn.BackColor = System.Drawing.Color.White;
            this.white_note_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.white_note_background_btn.ForeColor = System.Drawing.Color.White;
            this.white_note_background_btn.Location = new System.Drawing.Point(250, 578);
            this.white_note_background_btn.Name = "white_note_background_btn";
            this.white_note_background_btn.Size = new System.Drawing.Size(38, 47);
            this.white_note_background_btn.TabIndex = 40;
            this.white_note_background_btn.UseVisualStyleBackColor = false;
            this.white_note_background_btn.Click += new System.EventHandler(this.white_note_background_btn_Click);
            // 
            // note_background_colour_lbl
            // 
            this.note_background_colour_lbl.AutoSize = true;
            this.note_background_colour_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.note_background_colour_lbl.ForeColor = System.Drawing.Color.White;
            this.note_background_colour_lbl.Location = new System.Drawing.Point(14, 587);
            this.note_background_colour_lbl.Name = "note_background_colour_lbl";
            this.note_background_colour_lbl.Size = new System.Drawing.Size(208, 33);
            this.note_background_colour_lbl.TabIndex = 39;
            this.note_background_colour_lbl.Text = "Note Background";
            // 
            // black_note_text_btn
            // 
            this.black_note_text_btn.BackColor = System.Drawing.Color.Black;
            this.black_note_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.black_note_text_btn.ForeColor = System.Drawing.Color.White;
            this.black_note_text_btn.Location = new System.Drawing.Point(736, 578);
            this.black_note_text_btn.Name = "black_note_text_btn";
            this.black_note_text_btn.Size = new System.Drawing.Size(38, 47);
            this.black_note_text_btn.TabIndex = 48;
            this.black_note_text_btn.UseVisualStyleBackColor = false;
            this.black_note_text_btn.Click += new System.EventHandler(this.black_note_text_btn_Click);
            // 
            // red_note_text_btn
            // 
            this.red_note_text_btn.BackColor = System.Drawing.Color.Red;
            this.red_note_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.red_note_text_btn.ForeColor = System.Drawing.Color.White;
            this.red_note_text_btn.Location = new System.Drawing.Point(692, 577);
            this.red_note_text_btn.Name = "red_note_text_btn";
            this.red_note_text_btn.Size = new System.Drawing.Size(38, 47);
            this.red_note_text_btn.TabIndex = 47;
            this.red_note_text_btn.UseVisualStyleBackColor = false;
            this.red_note_text_btn.Click += new System.EventHandler(this.red_note_text_btn_Click);
            // 
            // yellow_note_text_btn
            // 
            this.yellow_note_text_btn.BackColor = System.Drawing.Color.Yellow;
            this.yellow_note_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yellow_note_text_btn.ForeColor = System.Drawing.Color.White;
            this.yellow_note_text_btn.Location = new System.Drawing.Point(648, 577);
            this.yellow_note_text_btn.Name = "yellow_note_text_btn";
            this.yellow_note_text_btn.Size = new System.Drawing.Size(38, 47);
            this.yellow_note_text_btn.TabIndex = 46;
            this.yellow_note_text_btn.UseVisualStyleBackColor = false;
            this.yellow_note_text_btn.Click += new System.EventHandler(this.yellow_note_text_btn_Click);
            // 
            // white_note_text_btn
            // 
            this.white_note_text_btn.BackColor = System.Drawing.Color.White;
            this.white_note_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.white_note_text_btn.ForeColor = System.Drawing.Color.White;
            this.white_note_text_btn.Location = new System.Drawing.Point(604, 578);
            this.white_note_text_btn.Name = "white_note_text_btn";
            this.white_note_text_btn.Size = new System.Drawing.Size(38, 47);
            this.white_note_text_btn.TabIndex = 45;
            this.white_note_text_btn.UseVisualStyleBackColor = false;
            this.white_note_text_btn.Click += new System.EventHandler(this.white_note_text_btn_Click);
            // 
            // note_text_colour_lbl
            // 
            this.note_text_colour_lbl.AutoSize = true;
            this.note_text_colour_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.note_text_colour_lbl.ForeColor = System.Drawing.Color.White;
            this.note_text_colour_lbl.Location = new System.Drawing.Point(455, 587);
            this.note_text_colour_lbl.Name = "note_text_colour_lbl";
            this.note_text_colour_lbl.Size = new System.Drawing.Size(121, 33);
            this.note_text_colour_lbl.TabIndex = 44;
            this.note_text_colour_lbl.Text = "Note Text";
            // 
            // online_notes_btn
            // 
            this.online_notes_btn.BackColor = System.Drawing.Color.Red;
            this.online_notes_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.online_notes_btn.ForeColor = System.Drawing.Color.White;
            this.online_notes_btn.Location = new System.Drawing.Point(138, 12);
            this.online_notes_btn.Name = "online_notes_btn";
            this.online_notes_btn.Size = new System.Drawing.Size(130, 64);
            this.online_notes_btn.TabIndex = 49;
            this.online_notes_btn.Text = "View Online Notes";
            this.online_notes_btn.UseVisualStyleBackColor = false;
            this.online_notes_btn.Click += new System.EventHandler(this.online_notes_btn_Click);
            // 
            // font_size_reset
            // 
            this.font_size_reset.BackColor = System.Drawing.Color.Red;
            this.font_size_reset.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_reset.ForeColor = System.Drawing.Color.White;
            this.font_size_reset.Location = new System.Drawing.Point(1075, 651);
            this.font_size_reset.Name = "font_size_reset";
            this.font_size_reset.Size = new System.Drawing.Size(38, 47);
            this.font_size_reset.TabIndex = 50;
            this.font_size_reset.Text = "↺";
            this.font_size_reset.UseVisualStyleBackColor = false;
            this.font_size_reset.Click += new System.EventHandler(this.font_size_reset_Click);
            // 
            // MyNotes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1125, 701);
            this.Controls.Add(this.font_size_reset);
            this.Controls.Add(this.online_notes_btn);
            this.Controls.Add(this.black_note_text_btn);
            this.Controls.Add(this.red_note_text_btn);
            this.Controls.Add(this.yellow_note_text_btn);
            this.Controls.Add(this.white_note_text_btn);
            this.Controls.Add(this.note_text_colour_lbl);
            this.Controls.Add(this.black_note_background_btn);
            this.Controls.Add(this.blue_note_background_btn);
            this.Controls.Add(this.yellow_note_backgrond_btn);
            this.Controls.Add(this.white_note_background_btn);
            this.Controls.Add(this.note_background_colour_lbl);
            this.Controls.Add(this.black_text_btn);
            this.Controls.Add(this.red_text_btn);
            this.Controls.Add(this.yellow_text_btn);
            this.Controls.Add(this.white_text_btn);
            this.Controls.Add(this.text_colour_lbl);
            this.Controls.Add(this.black_background_btn);
            this.Controls.Add(this.blue_background_btn);
            this.Controls.Add(this.yellow_background_btn);
            this.Controls.Add(this.white_background_btn);
            this.Controls.Add(this.background_colour_lbl);
            this.Controls.Add(this.font_size_down);
            this.Controls.Add(this.font_size_up);
            this.Controls.Add(this.font_size_lbl);
            this.Controls.Add(this.notearea);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.open_btn);
            this.Controls.Add(this.notepad);
            this.Controls.Add(this.new_btn);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.Title);
            this.Controls.Add(this.backlabel);
            this.Name = "MyNotes";
            this.Text = "MyNotes";
            ((System.ComponentModel.ISupportInitialize)(this.notepad)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Title;
        private Button Back_btn;
        private Button new_btn;
        private PictureBox notepad;
        private Button open_btn;
        private Button save_btn;
        private TextBox notearea;
        private Label backlabel;
        private SaveFileDialog saveFileDialog1;
        private FolderBrowserDialog folderBrowserDialog1;
        private OpenFileDialog openFileDialog1;
        private Button font_size_down;
        private Button font_size_up;
        private Label font_size_lbl;
        private Button black_text_btn;
        private Button red_text_btn;
        private Button yellow_text_btn;
        private Button white_text_btn;
        private Label text_colour_lbl;
        private Button black_background_btn;
        private Button blue_background_btn;
        private Button yellow_background_btn;
        private Button white_background_btn;
        private Label background_colour_lbl;
        private Button black_note_background_btn;
        private Button blue_note_background_btn;
        private Button yellow_note_backgrond_btn;
        private Button white_note_background_btn;
        private Label note_background_colour_lbl;
        private Button black_note_text_btn;
        private Button red_note_text_btn;
        private Button yellow_note_text_btn;
        private Button white_note_text_btn;
        private Label note_text_colour_lbl;
        private Button online_notes_btn;
        private Button font_size_reset;
    }
}