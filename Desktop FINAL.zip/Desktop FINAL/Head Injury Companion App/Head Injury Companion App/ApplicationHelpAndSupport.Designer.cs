﻿namespace Head_Injury_Companion_App
{
    partial class ApplicationHelpAndSupport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ApplicationHelpAndSupport));
            this.Title = new System.Windows.Forms.Label();
            this.apphelp = new System.Windows.Forms.PictureBox();
            this.Back_btn = new System.Windows.Forms.Button();
            this.faqweb = new Microsoft.Web.WebView2.WinForms.WebView2();
            this.font_size_down = new System.Windows.Forms.Button();
            this.font_size_up = new System.Windows.Forms.Button();
            this.font_size_lbl = new System.Windows.Forms.Label();
            this.black_text_btn = new System.Windows.Forms.Button();
            this.red_text_btn = new System.Windows.Forms.Button();
            this.yellow_text_btn = new System.Windows.Forms.Button();
            this.white_text_btn = new System.Windows.Forms.Button();
            this.text_colour_lbl = new System.Windows.Forms.Label();
            this.black_background_btn = new System.Windows.Forms.Button();
            this.blue_background_btn = new System.Windows.Forms.Button();
            this.yellow_background_btn = new System.Windows.Forms.Button();
            this.white_background_btn = new System.Windows.Forms.Button();
            this.background_colour_lbl = new System.Windows.Forms.Label();
            this.supportnumber_lbl = new System.Windows.Forms.Label();
            this.font_size_reset = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.apphelp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.faqweb)).BeginInit();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Arial Rounded MT Bold", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Title.ForeColor = System.Drawing.Color.White;
            this.Title.Location = new System.Drawing.Point(287, 9);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(620, 38);
            this.Title.TabIndex = 2;
            this.Title.Text = "Application Help and Support (FAQ\'s)";
            // 
            // apphelp
            // 
            this.apphelp.Image = ((System.Drawing.Image)(resources.GetObject("apphelp.Image")));
            this.apphelp.Location = new System.Drawing.Point(989, 12);
            this.apphelp.Name = "apphelp";
            this.apphelp.Size = new System.Drawing.Size(126, 114);
            this.apphelp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.apphelp.TabIndex = 12;
            this.apphelp.TabStop = false;
            // 
            // Back_btn
            // 
            this.Back_btn.BackColor = System.Drawing.Color.Red;
            this.Back_btn.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Back_btn.ForeColor = System.Drawing.Color.White;
            this.Back_btn.Location = new System.Drawing.Point(12, 12);
            this.Back_btn.Name = "Back_btn";
            this.Back_btn.Size = new System.Drawing.Size(120, 64);
            this.Back_btn.TabIndex = 14;
            this.Back_btn.Text = "Back";
            this.Back_btn.UseVisualStyleBackColor = false;
            this.Back_btn.Click += new System.EventHandler(this.Back_btn_Click);
            // 
            // faqweb
            // 
            this.faqweb.AllowExternalDrop = true;
            this.faqweb.CreationProperties = null;
            this.faqweb.DefaultBackgroundColor = System.Drawing.Color.White;
            this.faqweb.Location = new System.Drawing.Point(12, 133);
            this.faqweb.Name = "faqweb";
            this.faqweb.Size = new System.Drawing.Size(1102, 505);
            this.faqweb.Source = new System.Uri("https://adamso10.wixsite.com/head-injury-app-faq", System.UriKind.Absolute);
            this.faqweb.TabIndex = 15;
            this.faqweb.ZoomFactor = 1D;
            // 
            // font_size_down
            // 
            this.font_size_down.BackColor = System.Drawing.Color.Red;
            this.font_size_down.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_down.ForeColor = System.Drawing.Color.White;
            this.font_size_down.Location = new System.Drawing.Point(1033, 652);
            this.font_size_down.Name = "font_size_down";
            this.font_size_down.Size = new System.Drawing.Size(38, 47);
            this.font_size_down.TabIndex = 29;
            this.font_size_down.Text = "-";
            this.font_size_down.UseVisualStyleBackColor = false;
            this.font_size_down.Click += new System.EventHandler(this.font_size_down_Click);
            // 
            // font_size_up
            // 
            this.font_size_up.BackColor = System.Drawing.Color.Red;
            this.font_size_up.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_up.ForeColor = System.Drawing.Color.White;
            this.font_size_up.Location = new System.Drawing.Point(989, 652);
            this.font_size_up.Name = "font_size_up";
            this.font_size_up.Size = new System.Drawing.Size(38, 47);
            this.font_size_up.TabIndex = 28;
            this.font_size_up.Text = "+";
            this.font_size_up.UseVisualStyleBackColor = false;
            this.font_size_up.Click += new System.EventHandler(this.font_size_up_Click);
            // 
            // font_size_lbl
            // 
            this.font_size_lbl.AutoSize = true;
            this.font_size_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_lbl.ForeColor = System.Drawing.Color.White;
            this.font_size_lbl.Location = new System.Drawing.Point(867, 661);
            this.font_size_lbl.Name = "font_size_lbl";
            this.font_size_lbl.Size = new System.Drawing.Size(116, 33);
            this.font_size_lbl.TabIndex = 27;
            this.font_size_lbl.Text = "Font Size";
            // 
            // black_text_btn
            // 
            this.black_text_btn.BackColor = System.Drawing.Color.Black;
            this.black_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.black_text_btn.ForeColor = System.Drawing.Color.White;
            this.black_text_btn.Location = new System.Drawing.Point(734, 653);
            this.black_text_btn.Name = "black_text_btn";
            this.black_text_btn.Size = new System.Drawing.Size(38, 47);
            this.black_text_btn.TabIndex = 39;
            this.black_text_btn.UseVisualStyleBackColor = false;
            this.black_text_btn.Click += new System.EventHandler(this.black_text_btn_Click);
            // 
            // red_text_btn
            // 
            this.red_text_btn.BackColor = System.Drawing.Color.Red;
            this.red_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.red_text_btn.ForeColor = System.Drawing.Color.White;
            this.red_text_btn.Location = new System.Drawing.Point(690, 652);
            this.red_text_btn.Name = "red_text_btn";
            this.red_text_btn.Size = new System.Drawing.Size(38, 47);
            this.red_text_btn.TabIndex = 38;
            this.red_text_btn.UseVisualStyleBackColor = false;
            this.red_text_btn.Click += new System.EventHandler(this.red_text_btn_Click);
            // 
            // yellow_text_btn
            // 
            this.yellow_text_btn.BackColor = System.Drawing.Color.Yellow;
            this.yellow_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yellow_text_btn.ForeColor = System.Drawing.Color.White;
            this.yellow_text_btn.Location = new System.Drawing.Point(646, 652);
            this.yellow_text_btn.Name = "yellow_text_btn";
            this.yellow_text_btn.Size = new System.Drawing.Size(38, 47);
            this.yellow_text_btn.TabIndex = 37;
            this.yellow_text_btn.UseVisualStyleBackColor = false;
            this.yellow_text_btn.Click += new System.EventHandler(this.yellow_text_btn_Click);
            // 
            // white_text_btn
            // 
            this.white_text_btn.BackColor = System.Drawing.Color.White;
            this.white_text_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.white_text_btn.ForeColor = System.Drawing.Color.White;
            this.white_text_btn.Location = new System.Drawing.Point(602, 653);
            this.white_text_btn.Name = "white_text_btn";
            this.white_text_btn.Size = new System.Drawing.Size(38, 47);
            this.white_text_btn.TabIndex = 36;
            this.white_text_btn.UseVisualStyleBackColor = false;
            this.white_text_btn.Click += new System.EventHandler(this.white_text_btn_Click);
            // 
            // text_colour_lbl
            // 
            this.text_colour_lbl.AutoSize = true;
            this.text_colour_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.text_colour_lbl.ForeColor = System.Drawing.Color.White;
            this.text_colour_lbl.Location = new System.Drawing.Point(453, 662);
            this.text_colour_lbl.Name = "text_colour_lbl";
            this.text_colour_lbl.Size = new System.Drawing.Size(143, 33);
            this.text_colour_lbl.TabIndex = 35;
            this.text_colour_lbl.Text = "Text Colour";
            // 
            // black_background_btn
            // 
            this.black_background_btn.BackColor = System.Drawing.Color.Black;
            this.black_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.black_background_btn.ForeColor = System.Drawing.Color.White;
            this.black_background_btn.Location = new System.Drawing.Point(380, 653);
            this.black_background_btn.Name = "black_background_btn";
            this.black_background_btn.Size = new System.Drawing.Size(38, 47);
            this.black_background_btn.TabIndex = 34;
            this.black_background_btn.UseVisualStyleBackColor = false;
            this.black_background_btn.Click += new System.EventHandler(this.black_background_btn_Click);
            // 
            // blue_background_btn
            // 
            this.blue_background_btn.BackColor = System.Drawing.Color.Blue;
            this.blue_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.blue_background_btn.ForeColor = System.Drawing.Color.White;
            this.blue_background_btn.Location = new System.Drawing.Point(336, 652);
            this.blue_background_btn.Name = "blue_background_btn";
            this.blue_background_btn.Size = new System.Drawing.Size(38, 47);
            this.blue_background_btn.TabIndex = 33;
            this.blue_background_btn.UseVisualStyleBackColor = false;
            this.blue_background_btn.Click += new System.EventHandler(this.blue_background_btn_Click);
            // 
            // yellow_background_btn
            // 
            this.yellow_background_btn.BackColor = System.Drawing.Color.Yellow;
            this.yellow_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.yellow_background_btn.ForeColor = System.Drawing.Color.White;
            this.yellow_background_btn.Location = new System.Drawing.Point(292, 652);
            this.yellow_background_btn.Name = "yellow_background_btn";
            this.yellow_background_btn.Size = new System.Drawing.Size(38, 47);
            this.yellow_background_btn.TabIndex = 32;
            this.yellow_background_btn.UseVisualStyleBackColor = false;
            this.yellow_background_btn.Click += new System.EventHandler(this.yellow_background_btn_Click);
            // 
            // white_background_btn
            // 
            this.white_background_btn.BackColor = System.Drawing.Color.White;
            this.white_background_btn.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.white_background_btn.ForeColor = System.Drawing.Color.White;
            this.white_background_btn.Location = new System.Drawing.Point(248, 653);
            this.white_background_btn.Name = "white_background_btn";
            this.white_background_btn.Size = new System.Drawing.Size(38, 47);
            this.white_background_btn.TabIndex = 31;
            this.white_background_btn.UseVisualStyleBackColor = false;
            this.white_background_btn.Click += new System.EventHandler(this.white_background_btn_Click);
            // 
            // background_colour_lbl
            // 
            this.background_colour_lbl.AutoSize = true;
            this.background_colour_lbl.Font = new System.Drawing.Font("Arial Narrow", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.background_colour_lbl.ForeColor = System.Drawing.Color.White;
            this.background_colour_lbl.Location = new System.Drawing.Point(12, 661);
            this.background_colour_lbl.Name = "background_colour_lbl";
            this.background_colour_lbl.Size = new System.Drawing.Size(230, 33);
            this.background_colour_lbl.TabIndex = 30;
            this.background_colour_lbl.Text = "Background Colour";
            // 
            // supportnumber_lbl
            // 
            this.supportnumber_lbl.AutoSize = true;
            this.supportnumber_lbl.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.supportnumber_lbl.ForeColor = System.Drawing.Color.White;
            this.supportnumber_lbl.Location = new System.Drawing.Point(12, 102);
            this.supportnumber_lbl.Name = "supportnumber_lbl";
            this.supportnumber_lbl.Size = new System.Drawing.Size(572, 24);
            this.supportnumber_lbl.TabIndex = 40;
            this.supportnumber_lbl.Text = "If further support is required, contact us on +447847346585";
            // 
            // font_size_reset
            // 
            this.font_size_reset.BackColor = System.Drawing.Color.Red;
            this.font_size_reset.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.font_size_reset.ForeColor = System.Drawing.Color.White;
            this.font_size_reset.Location = new System.Drawing.Point(1077, 652);
            this.font_size_reset.Name = "font_size_reset";
            this.font_size_reset.Size = new System.Drawing.Size(38, 47);
            this.font_size_reset.TabIndex = 41;
            this.font_size_reset.Text = "↺";
            this.font_size_reset.UseVisualStyleBackColor = false;
            this.font_size_reset.Click += new System.EventHandler(this.font_size_reset_Click);
            // 
            // ApplicationHelpAndSupport
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Blue;
            this.ClientSize = new System.Drawing.Size(1127, 703);
            this.Controls.Add(this.font_size_reset);
            this.Controls.Add(this.supportnumber_lbl);
            this.Controls.Add(this.black_text_btn);
            this.Controls.Add(this.red_text_btn);
            this.Controls.Add(this.yellow_text_btn);
            this.Controls.Add(this.white_text_btn);
            this.Controls.Add(this.text_colour_lbl);
            this.Controls.Add(this.black_background_btn);
            this.Controls.Add(this.blue_background_btn);
            this.Controls.Add(this.yellow_background_btn);
            this.Controls.Add(this.white_background_btn);
            this.Controls.Add(this.background_colour_lbl);
            this.Controls.Add(this.font_size_down);
            this.Controls.Add(this.font_size_up);
            this.Controls.Add(this.font_size_lbl);
            this.Controls.Add(this.faqweb);
            this.Controls.Add(this.Back_btn);
            this.Controls.Add(this.apphelp);
            this.Controls.Add(this.Title);
            this.Name = "ApplicationHelpAndSupport";
            this.Text = "ApplicationHelpAndSupport";
            ((System.ComponentModel.ISupportInitialize)(this.apphelp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.faqweb)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Title;
        private PictureBox apphelp;
        private Button Back_btn;
        private Microsoft.Web.WebView2.WinForms.WebView2 faqweb;
        private Button font_size_down;
        private Button font_size_up;
        private Label font_size_lbl;
        private Button black_text_btn;
        private Button red_text_btn;
        private Button yellow_text_btn;
        private Button white_text_btn;
        private Label text_colour_lbl;
        private Button black_background_btn;
        private Button blue_background_btn;
        private Button yellow_background_btn;
        private Button white_background_btn;
        private Label background_colour_lbl;
        private Label supportnumber_lbl;
        private Button font_size_reset;
    }
}